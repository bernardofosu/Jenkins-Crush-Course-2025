# 📂 Why `/etc/vault.d/` ?

In Linux, it’s common to use a **`.d` directory convention** for configuration.  
The `.d` means **“drop-in directory”** → a place where the main program reads multiple config files.  

Examples:  
- `/etc/systemd/system.conf.d/`  
- `/etc/nginx/conf.d/`  
- `/etc/apt/sources.list.d/`  

👉 So, HashiCorp chose `/etc/vault.d/` as Vault’s default config directory.  

- By default, Vault loads `/etc/vault.d/vault.hcl` (main config file).  
- You can also drop in extra `.hcl` files in that directory and Vault will merge them.  

---

## 🔑 Why are the certs there too?

You copied:  
- `/etc/vault.d/vault.crt` → TLS certificate (public part).  
- `/etc/vault.d/vault.key` → TLS private key.  

You *could* store them elsewhere (`/etc/ssl/...`, `/opt/certs/...`) and just point to them in `vault.hcl`.  
Putting them in `/etc/vault.d/` is just **convenient**:  
- Keeps all Vault-related files (config + certs) in one place.  
- Matches examples in HashiCorp docs/tutorials.  

---

## 📂 Why `/etc/ssl/` ?

On Linux/Unix systems, there are a few **“standard” directories** for SSL/TLS materials:  
- `/etc/ssl/certs/` → trusted CA certificates (public certs)  
- `/etc/ssl/private/` → private keys (restricted perms)  
- `/etc/ssl/` → general location for SSL-related files  

That’s why many services (Nginx, Apache, Postfix, etc.) keep certs under `/etc/ssl/` to follow convention.  

---

## ⚖️ Pros & Cons

| Location            | Pros ✅ | Cons ⚠️ |
|---------------------|---------|---------|
| `/etc/vault.d/`     | All Vault-related config & certs in one place, easy to back up | Not a “standard” SSL path (mixes config + certs) |
| `/etc/ssl/vault/`   | Follows Linux convention (certs under `/etc/ssl/`) | Splits Vault config & certs across folders |
| `/etc/ssl/private/` | Extra secure (keys usually mode `600`, root-only) | Vault user needs explicit access |

---

## 🔐 Best Practice

- **Production**  
  - Put the **private key** under `/etc/ssl/private/` (mode `600`, owner `root:vault`).  
  - Put the **cert chain** under `/etc/ssl/certs/`.  
  - Update `vault.hcl` to point to those paths.  

- **Dev/Lab**  
  - Fine to keep certs/keys in `/etc/vault.d/` for convenience.  

---

✨ So the reason `/etc/ssl/` exists is because it’s the **traditional place for system-wide SSL/TLS certificates & keys**, while `/etc/vault.d/` is specific to Vault configs.  
