# 🔒 What is mlock?

**mlock** is a Linux system call that locks memory pages so they cannot be swapped out to disk.  

- Vault uses it to keep **encryption keys only in RAM**.  
- This prevents sensitive data from accidentally ending up in swap space (which could be written to disk and leak secrets).  

---

## ⚙️ Vault Config Option

In `vault.hcl` you often see:  

```hcl
# If you configure CAP_IPC_LOCK properly, you can set this to false
# and remove disable_mlock; for simplicity here we keep it true
disable_mlock = true
```

- `disable_mlock = false` → Vault **will try to mlock memory**.  
  ✅ Safer for production.  
  ⚠️ Requires Vault’s process to have the Linux capability **CAP_IPC_LOCK**.  
  ❌ Without that, Vault fails to start with a permission error.  

- `disable_mlock = true` → Vault **doesn’t try to mlock memory**.  
  👍 Easier for dev/test setups (no special privileges needed).  
  ⚠️ Slightly less secure, because keys can be swapped to disk if the OS runs low on memory.  

---

## ✅ Why keep `disable_mlock = true` in your setup?

- **Simplicity:** no need to grant `CAP_IPC_LOCK` or run Vault as root.  
- **Convenience:** works out of the box on Ubuntu without touching systemd/kernel caps.  
- **Tradeoff:** less secure, but acceptable for **lab, dev, or learning clusters**.  

---

## 🔐 Best practice for production

1. Run Vault as a dedicated user (`vault`).  
2. Give it the `CAP_IPC_LOCK` capability:  

```bash
sudo setcap cap_ipc_lock=+ep $(which vault)
```

3. Then set in `vault.hcl`:  

```hcl
disable_mlock = false
```

4. (Recommended) Configure systemd to persist the capability:  

```ini
[Service]
CapabilityBoundingSet=CAP_IPC_LOCK
AmbientCapabilities=CAP_IPC_LOCK
LimitMEMLOCK=infinity
```

Reload & restart:  
```bash
sudo systemctl daemon-reload
sudo systemctl restart vault
```

Verify:  
```bash
journalctl -u vault -b | grep -i mlock
```

You should **not** see “mlock is not supported” or “mlock disabled”.  

---

## ✨ TL;DR

- **mlock** = prevents secrets in memory from being written to disk (swap).  
- `disable_mlock = true` → convenient but less secure → good for **dev/test**.  
- `disable_mlock = false` + `CAP_IPC_LOCK` → **best practice for production**.  


🧠 RAM vs 💽 Swap (HDD/SSD)

RAM (Memory):

Very fast, temporary storage.

When you shut down or reboot, contents are wiped.

Vault keeps encryption keys here by default.

Safer, because RAM is harder for an attacker to access once power is lost.

Swap (on HDD/SSD):

When RAM is full, the OS moves some memory pages to disk (called swap space).

This is literally stored on your hard disk/SSD.

Risk: if Vault’s sensitive memory (keys, tokens) is swapped, those secrets could end up as plain text in a file on disk.

Disks are persistent → forensic tools or an attacker could recover those secrets later.

🔒 Why mlock Matters

mlock tells the OS:
👉 “Never move Vault’s memory to swap, always keep it in RAM.”

This ensures Vault’s encryption keys never touch disk.

⚖️ Security Takeaway

Yes — information in RAM is safer than on HDD/SSD (swap).

That’s why in production we prefer:

disable_mlock = false

Vault runs with CAP_IPC_LOCK

So secrets stay locked in memory.

For dev/test it’s fine to skip (disable_mlock = true) because the convenience outweighs the small risk.