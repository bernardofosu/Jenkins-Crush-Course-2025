# 🗓️ Today’s Vault Troubleshooting Log

## 1) 🚨 vault status failed (HTTPS vs HTTP)

**Symptom**
```
WARNING! VAULT_ADDR and -address unset. Defaulting to https://127.0.0.1:8200
Error checking seal status: ... http: server gave HTTP response to HTTPS client
```

**Cause**  
Vault UI/API was running on HTTP (no TLS), but the CLI defaulted to HTTPS.

**Fix**
```bash
export VAULT_ADDR="http://54.90.150.15:8200"   # follower’s API
vault status
```

**Result** ✅ CLI connected; status showed `Initialized: false`, `Storage Type: raft`, `HA Enabled: true`.

**Prevention**
```bash
echo 'export VAULT_ADDR=http://54.90.150.15:8200' >> ~/.bashrc
# or point to leader during admin work:
# echo 'export VAULT_ADDR=http://172.31.17.74:8200' >> ~/.bashrc
```

---

## 2) 🧭 “Raft backend not in use” when joining

**Symptom**
```
Error: raft backend not in use
```

**Cause**  
Node was still configured with `storage "file"` (or data dir contained old “file” data).

**Fix**
```hcl
storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-node-…"
  retry_join { leader_api_addr = "http://<LEADER>:8200" }
}
```

Emptied follower’s data dir before join (lab only):
```bash
sudo systemctl stop vault
sudo rm -rf /opt/vault/data/*
sudo systemctl start vault
```

**Result** ✅ Join succeeded after using Raft on both nodes.

**Prevention**  
Use Raft for HA; don’t mix `file` and `raft`. For migrations, use `vault operator migrate` (not `rm -rf`) in prod.

---

## 3) 🧩 cluster_addr vs cluster_address / api_addr

**Symptom**
```
Logs: unknown or unsupported field cluster_addr
Peers not seeing each other
```

**Cause**  
Mixed up fields:
- Listener block uses `cluster_address` (with **ess**)  
- Top-level advertises `cluster_addr` (without “ess”)

**Fix (example)**
```hcl
listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_disable     = 1
}

api_addr     = "http://<PUBLIC_OR_LB>:8200"     # for clients
cluster_addr = "http://<PRIVATE_IP>:8201"       # for peers
```

**Result** ✅ Warnings gone; cluster comms OK.

---

## 4) 🔒 “cipher: message authentication failed” in UI

**Symptom**  
While unsealing via UI, error about decrypting Shamir shares.

**Cause**  
Unseal keys didn’t match the data in `/opt/vault/data` (old keys, changed backend, or moved data).

**Fix (lab)**
```bash
sudo systemctl stop vault
sudo rm -rf /opt/vault/data/*
sudo systemctl start vault
# Re-init on leader, or join follower then unseal with correct shares
```

**Prod note**: Use `vault operator migrate` or restore from backup; don’t wipe.

---

## 5) 🔗 Follower join URL typo

**Symptom**
```bash
vault operator raft join http://50.17.109.80:8200:8200
```

**Cause**  
Port repeated (`:8200:8200`).

**Fix**
```bash
vault operator raft join http://50.17.109.80:8200
```

**Result** ✅ Join request reached leader.

---

## 6) 🧪 TLS toggles & systemd failures

**Symptom**  
Service failed to start when TLS was expected/absent. Wrong listener options (`tls_disable` vs cert files).

**Cause**  
Config mismatch (enabling TLS without certs, or switching between HTTP/HTTPS without updating clients).

**Fix (dev HTTP)**
```hcl
listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_disable     = 1
}
```

**Fix (TLS)**  
Provide `tls_cert_file` / `tls_key_file` and use `https://…` everywhere (including `VAULT_ADDR`).

**Reminder**  
After editing `vault.hcl`:
```bash
sudo systemctl restart vault   # restart = stop+start; Vault will be sealed again
```

---

## 7) 🧷 Not initializing followers

**Observation**  
Follower showed:
```
Initialized false, Sealed true, Storage Type raft, HA Enabled true
```

**Meaning**  
That’s correct before join: followers are **not** initialized.  
They join the leader and then are unsealed using the same shares (any 3 of 5).

---

## 8) ❌ “Vault is not initialized” during unseal (Leader)

**Symptom**
```bash
ubuntu@Vault-Leader:~$ vault operator unseal XX+fLy2k+...
Error unsealing: Error making API request.

URL: PUT http://50.17.109.80:8200/v1/sys/unseal
Code: 400. Errors:

* Vault is not initialized
```

**Cause**  
Tried to **unseal before initializing** the leader.  
Followers must not be initialized, but the **leader must** be initialized once with `vault operator init` (or UI “Initialize”).

**Fix (Leader only)**
```bash
export VAULT_ADDR="http://50.17.109.80:8200"
vault operator init -key-shares=5 -key-threshold=3 > ~/vault_init.txt

# Copy the unseal keys + root token securely
vault operator unseal <key1>
vault operator unseal <key2>
vault operator unseal <key3>
```

**Result** ✅ After init + 3 unseal keys, leader becomes active.  
Followers can then `raft join` and be unsealed with the same keys.

**Prevention**  
Always `vault operator init` **once** (leader only) before attempting `vault operator unseal`.

9) 2 errors occurred: permission denied and invalid token

```sh
Error reading the raft cluster configuration: Error making API request.

URL: GET http://50.17.109.80:8200/v1/sys/storage/raft/configuration
Code: 403. Errors:

* 2 errors occurred:
        * permission denied
        * invalid token
```
Solve by login
```sh
vault login hvs.glx8yESJR1D5T9guAoRmmvgp
```

## Path not enable error 403
```sh
Error making API request.

URL: GET http://50.17.109.80:8200/v1/sys/internal/ui/mounts/secret/app
Code: 403. Errors:

* preflight capability check returned 403, please ensure client's policies grant access to path "secret/app/"
```

Solve
```sh
# (only if you intended a 'secrets/' mount and it doesn't exist yet)
vault secrets enable -path=secrets kv-v2
vault kv metadata get secrets/app

Success! Enabled the kv-v2 secrets engine at: secret/
```

10) Error checking seal status
```sh
Error checking seal status: Get "https://50.17.109.80:8200/v1/sys/seal-status": http: server gave HTTP response to HTTPS client
```
100 That means Vault CLI was still trying HTTPS, not HTTP
```sh
export VAULT_ADDR="http://EC2_PUBLIC_IP:8200"

echo 'export VAULT_ADDR=http://50.17.109.80:8200' >> ~/.bashrc
source ~/.bashrc # make permanent
```

# ✅ Current Status

We now have all the major errors captured:

- ⚡ Wrong protocol (http/https)  
- 📦 Wrong backend (file vs raft)  
- 📝 Config typos (`cluster_addr`)  
- 🔑 Unseal key mismatch  
- 🔗 Follower join mistakes  
- 🟢 Missing leader initialization
