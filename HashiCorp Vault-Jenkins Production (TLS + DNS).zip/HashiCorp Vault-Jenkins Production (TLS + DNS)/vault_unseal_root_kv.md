# 🔐 Vault Unseal, Root Login & KV v2 Setup

## 🚪 Unseal Vault
```bash
vault operator unseal <key-1>
vault operator unseal <key-2>
vault operator unseal <key-3>
vault status
```

📌 At init, Vault was sealed with **Shamir’s Secret Sharing**.  
👉 You must enter at least **3 unseal keys** (because `-key-threshold=3`).  
✅ After 3 valid keys, Vault is unsealed and ready.  
🩺 `vault status` confirms Vault’s health.  

---

## 👑 1️⃣1️⃣ Login as Root (Initial)
```bash
vault login <initial-root-token>
```

🔑 The root token (printed during `vault operator init`) lets you log in as the **super-admin**.  
⚡ With it, you can:  
- Enable secrets engines  
- Write policies  
- Manage tokens  

⚠️ **Best practice:** use it only for **bootstrap**, then create limited admin tokens.  

---

## 📂 1️⃣2️⃣ Enable KV v2 & Test Secrets
```bash
vault secrets enable -path=secret kv-v2
```

📦 Enables the **Key-Value (KV) secrets engine**, version 2 at path `/secret/`.  
✨ KV v2 supports:  
- Versioning  
- History  
- Undelete  

---

✅ You’re now ready to start storing and retrieving secrets in Vault!
