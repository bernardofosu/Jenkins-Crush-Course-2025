# 🔑 Jenkins ↔ HashiCorp Vault Integration

## 🧩 Step 1: Install the Vault Plugin
- Go to **Manage Jenkins → Plugins → Available**  
- Install **HashiCorp Vault Plugin** 
- Install **Hashicorp Vault Pipeline Version** 

⚠️ **Note:** After installation, Vault configuration is under **Manage Jenkins → System**, not under Tools.

---

## 🧩 Step 2: Configure Vault in Jenkins (System Settings)
Navigate to: **Manage Jenkins → System**  
Scroll to **Vault Plugin**  

Fill in:  
- **Vault URL:** e.g., `https://nakodtech.xyz:8200`  
- **Vault Credential:** (we will add the Vault token below)  
- **K/V Engine Version:** `2` ✅ (important, otherwise Jenkins won’t find your paths)  
- (Optional) Tick **Skip SSL Verification** if you’re not using TLS/SSL yet 🔓  
- **Timeout:** leave default or adjust (e.g., `60s`)  

---

## 🧩 Step 3: Add Vault Token as a Jenkins Credential
Go to: **Manage Jenkins → Credentials → Global → Add Credentials**  

Fill in:  
- **Kind:** Vault Token Credential  
- **Scope:** Global  
- **Token:** paste the Vault token you created in Vault  
- **ID:** e.g., `vault-token` (easy to reference later)  

💾 Save

---

## 🧩 Step 4: Link Vault Credential to System Config
- Back in **Manage Jenkins → System → Vault Plugin**  
- Under **Vault Credential**, select the token credential you just added (`vault-token`).  
- 💾 Save

---

## 🧩 Step 5: Use Vault Secrets in Pipelines
Example **Jenkinsfile** using Vault plugin:
```groovy
pipeline {
  agent any
  environment {
    // Reads secret at path: secret/data/jenkins/docker
    VAULT_SECRET = vault path: 'secret/jenkins/docker', key: 'password'
  }
  stages {
    stage('Show Secret') {
      steps {
        echo "Password from Vault is: ${env.VAULT_SECRET}"
      }
    }
  }
}
```

---

## ⚠️ Notes / Gotchas
- After installing the plugin, always configure Vault in **System**, otherwise pipeline steps will throw errors.  
- You must configure the **Vault token at System first**, otherwise Jenkins can’t authenticate.  
- Always set **KV Engine Version = 2** if your secrets engine is KV v2.  
- If you’re not using TLS/SSL yet → tick **Skip SSL verification**.  
  - Later, when TLS is enabled, uncheck this and add proper certs.  

---


The secrets are being fetched (you can see Retrieving secret: secret/jenkins/docker and the masked ****). The warning is just about the step parameters:

WARNING: Unknown parameter(s) ... 'vaultCredentialId'

That happens when you’ve already set the Vault Credential in Manage Jenkins → System → Vault Plugin. In that case, passing vaultCredentialId inside withVault is redundant and the step class doesn’t expect it—so it warns but still works using the global config.

✅ Option A — Use the global Vault config (no warning)

Keep your System config (URL + Credential) and remove vaultCredentialId from the step:

pipeline {
  agent any
  stages {
    stage('Use Vault Secrets') {
      steps {
        withVault(
          vaultSecrets: [[
            path: 'secret/jenkins/docker',  // KV v2 path (no /data/)
            engineVersion: 2,
            secretValues: [
              [vaultKey: 'username', envVar: 'DOCKER_USERNAME'],
              [vaultKey: 'password', envVar: 'DOCKER_PASSWORD']
            ]
          ]]
        ) {
          sh '''
            echo "Username from Vault: $DOCKER_USERNAME"
            echo "Password from Vault: $DOCKER_PASSWORD"   # avoid echo in real jobs
          '''
        }
      }
    }
  }
}

### ✅ Option B — Pin Vault URL/credential per job (no global needed)

If you prefer the pipeline to be self-contained, pass the configuration and the credential ID explicitly:
```groovy
pipeline {
  agent any
  stages {
    stage('Use Vault Secrets (job-scoped)') {
      steps {
        withVault(
          configuration: [
            url: 'https://nakodtech.xyz:8200',
            engineVersion: 2,
            // set to true only if you don't have TLS properly set up:
            // skipSslVerification: true,
            timeout: 60
          ],
          vaultCredentialId: 'vault-token',   // ID of your Vault Token Credential
          vaultSecrets: [[
            path: 'secret/jenkins/docker',
            secretValues: [
              [vaultKey: 'username', envVar: 'DOCKER_USERNAME'],
              [vaultKey: 'password', envVar: 'DOCKER_PASSWORD']
            ]
          ]]
        ) {
          sh 'echo "User: $DOCKER_USERNAME"'
        }
      }
    }
  }
}
```
Quick checklist

KV v2: keep engineVersion: 2. Path should be secret/... (no /data/).

System config path: Manage Jenkins → System → Vault Plugin (not Tools).

Credential kind: “Vault Token Credential” (ID e.g., vault-token).

TLS: if you’re not using TLS yet, tick Skip SSL verification in System config, or add skipSslVerification: true in configuration: (Option B). Turn this off once you have proper HTTPS.

If you still see that warning after removing vaultCredentialId, let me know your plugin version and I’ll tailor the exact syntax for it.


### 👍 — in Jenkins Pipelines, anything you pull from Vault inside the withVault {} block is exposed as environment variables (envVar).

🔑 How environment variables behave

Inside the withVault {} block → they are set as normal shell env vars.

When the block ends → by default, they are gone.

If you want to use them outside the block, you need to copy them into Jenkins’ pipeline env object or stash them in Groovy variables.

✅ Example 1: Promote to env (Jenkins global env object)
```
pipeline {
  agent any
  stages {
    stage('Fetch Vault Secrets') {
      steps {
        script {
          withVault([
            vaultSecrets: [[
              path: 'secret/jenkins/docker',
              engineVersion: 2,
              secretValues: [
                [vaultKey: 'username', envVar: 'DOCKER_USERNAME'],
                [vaultKey: 'password', envVar: 'DOCKER_PASSWORD']
              ]
            ]],
            vaultCredentialId: 'vault-token'
          ]) {
            // Copy Vault secrets to pipeline env for later stages
            env.MY_USER = env.DOCKER_USERNAME
            env.MY_PASS = env.DOCKER_PASSWORD
          }
        }
      }
    }

    stage('Use Later') {
      steps {
        sh '''
          echo "Now using outside Vault block"
          echo "Username = $MY_USER"
          echo "Password = $MY_PASS"
        '''
      }
    }
  }
}
```

✅ Example 2: Store in Groovy vars
```
pipeline {
  agent any
  stages {
    stage('Fetch') {
      steps {
        script {
          def user
          def pass
          withVault([
            vaultSecrets: [[
              path: 'secret/jenkins/docker',
              engineVersion: 2,
              secretValues: [
                [vaultKey: 'username', envVar: 'DOCKER_USERNAME'],
                [vaultKey: 'password', envVar: 'DOCKER_PASSWORD']
              ]
            ]],
            vaultCredentialId: 'vault-token'
          ]) {
            user = env.DOCKER_USERNAME
            pass = env.DOCKER_PASSWORD
          }
          // Now we can use Groovy vars outside the block
          echo "Fetched user: ${user}"
          echo "Fetched pass: ${pass}"
        }
      }
    }
  }
}
```
⚠️ Security tip
Don’t echo passwords in real jobs — instead, pass them directly into docker login, API calls, etc. Example:
```sh
sh '''
  echo "$MY_PASS" | docker login -u "$MY_USER" --password-stdin
'''
````