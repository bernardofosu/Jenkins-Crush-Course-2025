# 🔑 Jenkins Vault Secrets — `environment {}` vs `withVault {}`

## 👀 Key Difference
- **`environment { vault ... }`** → Injects values as plain environment variables.  
- **`withVault {}`** → Injects values as masked secrets (hidden in logs).  

---

## 🧩 Why passwords show in the first example
Example:
```groovy
environment {
  VAULT_SECRET = vault path: 'secret/jenkins/docker', key: 'password'
}
```

- Jenkins injects the Vault value directly into an env var.  
- That env var is **not masked** by the Vault plugin.  
- If you `echo ${env.VAULT_SECRET}`, Jenkins prints the raw string.  

➡️ **Result:** Password is visible in logs.

---

## 🧩 Why the second example shows `****`
Example:
```groovy
withVault(
  vaultSecrets: [[
    path: 'secret/jenkins/docker',
    engineVersion: 2,
    secretValues: [
      [vaultKey: 'username', envVar: 'DOCKER_USERNAME'],
      [vaultKey: 'password', envVar: 'DOCKER_PASSWORD']
    ]
  ]]
) {
  sh '''
    echo "Password from Vault: $DOCKER_PASSWORD"
  '''
}
```

- Vault plugin registers these env vars as **masked secrets**.  
- Jenkins console log filters them → replaces with `****`.  
- Even if you accidentally echo them, they won’t be visible.  

➡️ **Result:** Passwords are hidden.

---

## ⚡ TL;DR
- `environment { vault ... }` → **plain injection, no masking → visible**  
- `withVault {}` → **masked injection → hidden as `****`**  

---

## ✅ Best Practice
Always use **withVault** for sensitive values (passwords, tokens, API keys).  
You can still promote them to global env vars if needed — they’ll remain masked in logs.  
