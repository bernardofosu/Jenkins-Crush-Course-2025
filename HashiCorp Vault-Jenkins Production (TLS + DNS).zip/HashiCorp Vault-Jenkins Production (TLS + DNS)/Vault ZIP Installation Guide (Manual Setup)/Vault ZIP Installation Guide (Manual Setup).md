# 📦 Vault ZIP Installation Guide (Manual Setup)

---

## 📦 1. Download Vault (ZIP binary)

HashiCorp distributes Vault binaries as `.zip` files.

👉 Official releases page:
[https://developer.hashicorp.com/vault/downloads](https://developer.hashicorp.com/vault/downloads)

Example for **Linux x86\_64 (64-bit)**:

```bash
curl -fsSL https://releases.hashicorp.com/vault/1.18.3/vault_1.18.3_linux_amd64.zip -o vault.zip
```

(Replace `1.18.3` with the version you want.)

---

## 📂 2. Extract ZIP and move binary

```bash
unzip vault.zip
sudo mv vault /usr/local/bin/
vault --version
```

This puts the **vault binary** in your PATH.

---

## 🗂️ 3. Manual project structure

When installing from ZIP, you must create dirs yourself:

```bash
# Config directory
sudo mkdir -p /etc/vault.d
sudo chown -R vault:vault /etc/vault.d

# Data directory
sudo mkdir -p /opt/vault/data
sudo chown -R vault:vault /opt/vault
```

* `/usr/local/bin/vault` → Vault binary
* `/etc/vault.d/` → Configs (`vault.hcl`, certs, env file)
* `/opt/vault/data/` → Storage backend data (Raft, file, etc.)
* `/etc/vault.d/vault.env` → Optional environment variables

---

## ⚙️ 4. Create systemd unit (manually)

Since ZIP install doesn’t ship `vault.service`, you write your own:

```bash
sudo nano /etc/systemd/system/vault.service
```

Paste:

```ini
[Unit]
Description=HashiCorp Vault - A tool for managing secrets
Documentation=https://developer.hashicorp.com/vault/docs
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/vault.d/vault.hcl
StartLimitIntervalSec=60
StartLimitBurst=3

[Service]
Type=notify
EnvironmentFile=-/etc/vault.d/vault.env
User=vault
Group=vault
ProtectSystem=full
ProtectHome=read-only
PrivateTmp=yes
PrivateDevices=yes
SecureBits=keep-caps
AmbientCapabilities=CAP_IPC_LOCK
CapabilityBoundingSet=CAP_SYSLOG CAP_IPC_LOCK
NoNewPrivileges=yes
ExecStart=/usr/local/bin/vault server -config=/etc/vault.d/vault.hcl
ExecReload=/bin/kill --signal HUP $MAINPID
KillMode=process
KillSignal=SIGINT
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
LimitNOFILE=65536
LimitMEMLOCK=infinity
LimitCORE=0

[Install]
WantedBy=multi-user.target
```

Save, exit, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable vault
sudo systemctl start vault
sudo systemctl status vault --no-pager
```

---

## 📝 5. Which files to edit?

* `/etc/vault.d/vault.hcl` → Vault configuration (storage, listener, API, cluster\_addr, etc.).
* `/etc/vault.d/vault.env` → Optional environment vars (e.g., `VAULT_ADDR`, `VAULT_API_ADDR`).
* `/etc/systemd/system/vault.service` → Only if you need to change how Vault starts (binary path, user, systemd limits).

---

## 🤖 6. Automation Script

Here’s a **ready-to-run bash script** that automates the whole ZIP install:

```bash
#!/bin/bash

VAULT_VERSION="1.18.3"

# Install deps
sudo apt update && sudo apt install -y unzip curl gnupg

# Download Vault
curl -fsSL https://releases.hashicorp.com/vault/${VAULT_VERSION}/vault_${VAULT_VERSION}_linux_amd64.zip -o vault.zip

# Extract and move binary
unzip vault.zip
sudo mv vault /usr/local/bin/
rm vault.zip

# Create vault user if not exists
if ! id -u vault >/dev/null 2>&1; then
  sudo useradd --system --home /etc/vault.d --shell /bin/false vault
fi

# Create dirs
sudo mkdir -p /etc/vault.d
sudo mkdir -p /opt/vault/data
sudo chown -R vault:vault /etc/vault.d /opt/vault

# Create systemd unit
cat <<EOF | sudo tee /etc/systemd/system/vault.service
[Unit]
Description=HashiCorp Vault - A tool for managing secrets
Documentation=https://developer.hashicorp.com/vault/docs
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/vault.d/vault.hcl
StartLimitIntervalSec=60
StartLimitBurst=3

[Service]
Type=notify
EnvironmentFile=-/etc/vault.d/vault.env
User=vault
Group=vault
ExecStart=/usr/local/bin/vault server -config=/etc/vault.d/vault.hcl
ExecReload=/bin/kill --signal HUP \$MAINPID
KillMode=process
KillSignal=SIGINT
Restart=on-failure
RestartSec=5
LimitNOFILE=65536
LimitMEMLOCK=infinity

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and start Vault
sudo systemctl daemon-reload
sudo systemctl enable vault
sudo systemctl start vault

# Verify
vault --version
sudo systemctl status vault --no-pager
```

---

✅ **Summary:**

* Download ZIP from HashiCorp site.
* Extract binary → `/usr/local/bin/vault`.
* Create config dir `/etc/vault.d/` and data dir `/opt/vault/data/`.
* Write your own `vault.service` unit or use the script above. 🚀
