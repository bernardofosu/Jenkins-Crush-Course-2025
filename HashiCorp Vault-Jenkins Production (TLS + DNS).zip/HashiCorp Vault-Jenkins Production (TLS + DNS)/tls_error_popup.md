## TLS Error popup


![alt text](image.png)


tls_require_and_verify_client_cert = true

sudo systemctl restart vault
