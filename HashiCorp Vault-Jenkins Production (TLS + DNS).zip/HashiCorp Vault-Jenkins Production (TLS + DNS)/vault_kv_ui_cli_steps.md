# 🔐 Vault KV v2 — Create & Read Secrets (UI + CLI)

This guide shows how to **create a secret from the Vault UI**, **read it from the UI**, and **read/write it from the CLI**. Works for a KV v2 mount at **`secret/`**.

## 🖥️ Part A — Create a Secret from the **UI**
1. Open **Vault UI** → **Secrets Engines** → click the **`secret` (version 2)** mount.  
2. Click **Create secret** (top‑right).  
3. **Path for this secret**: enter a path, e.g. `myapp` or `myapp/db`.  
4. **Secret data**: add key/value pairs, e.g.  
   - `username` → `admin`  
   - `password` → `supersecure123`  
   *(You can also toggle **JSON** and paste a JSON object.)*  
5. (Optional) Click **Show secret metadata** to set custom metadata/tags.  
6. Click **Save**. You should now see **version 1** created under the path.

### 🔎 Read from the UI
1. In **Secrets Engines → secret**, click your path (e.g., **`myapp`**).  
2. The latest **version** is shown; click to **reveal** values.  
3. Use the **Version** dropdown to read older versions if they exist.

---

## 💻 Part B — CLI: Login & Basic Operations
### 1) Login
```bash
vault login <your-token>
```
> Use a scoped token for day‑to‑day use; avoid the root token in production.

### 2) Write (creates version 1, then 2, …)
```bash
vault kv put secret/myapp username=admin password='supersecure123'
```

### 3) Read (latest version by default)
```bash
vault kv get secret/myapp
```

### 4) Read a specific version
```bash
vault kv get -version=1 secret/myapp
```

### 5) List keys
```bash
vault kv list secret/
```

### 6) JSON output (handy for scripts)
```bash
vault kv get -format=json secret/myapp | jq -r '.data.data'
```

---

## 🌐 Part C — HTTP API (KV v2 paths)
> KV v2 uses **`/data/`** for reads/writes and **`/metadata/`** for metadata ops.

### Write via API
```bash
curl -s -H "X-Vault-Token: $VAULT_TOKEN"   -H "Content-Type: application/json"   -X POST   --data '{"data":{"username":"admin","password":"supersecure123"}}'   "$VAULT_ADDR/v1/secret/data/myapp"
```

### Read via API
```bash
curl -s -H "X-Vault-Token: $VAULT_TOKEN"   "$VAULT_ADDR/v1/secret/data/myapp"
```

---

## 🛡️ Policies for KV v2 (common gotcha)
Grant **data** and **metadata** paths:
```hcl
# read/create/update/delete secret data
path "secret/data/*" {
  capabilities = ["create", "update", "read", "delete", "list"]
}

# list, read metadata, delete metadata, destroy versions
path "secret/metadata/*" {
  capabilities = ["list", "read", "delete", "update"]
}
```
> If you only allow `secret/*` like KV v1, reads will fail in KV v2.

---

## 🧹 Part D — Maintenance & Version Ops
```bash
# Soft-delete version(s) (can be undeleted)
vault kv delete -versions=2 secret/myapp

# Undelete version(s)
vault kv undelete -versions=2 secret/myapp

# Permanently destroy version(s)
vault kv destroy -versions=2 secret/myapp

# Delete ALL versions + metadata (irrevocable)
vault kv metadata delete secret/myapp
```

---

## 🚑 Troubleshooting
- **permission denied** → token lacks policy on `secret/data/*` or `secret/metadata/*`.  
- **404 or "no value"** → wrong path; for API use `/v1/secret/data/<path>`.  
- **TLS errors** → set `VAULT_CACERT` (and client cert/key if mTLS).  
- **UI shows v1** → ensure mount is **KV v2** (path shows “version 2”).

---

## ✅ Summary
- UI: **Create secret** → choose a **path** → add **key/value(s)** → **Save** → read via UI.  
- CLI: `vault kv put secret/<path> ...` and `vault kv get secret/<path>`.  
- API: Use `/v1/secret/data/<path>` for reads/writes in KV v2.  
- Remember policies must target **`secret/data/*`** and **`secret/metadata/*`**. 🧩
