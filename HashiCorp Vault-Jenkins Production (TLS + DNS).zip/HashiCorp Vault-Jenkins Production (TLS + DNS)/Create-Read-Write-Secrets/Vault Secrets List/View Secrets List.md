# 🧭 Vault Secrets List — Pretty Print Options

## 🧹 Option 1 — Use JSON + `jq` for pretty print

```bash
vault secrets list -detailed -format=json | jq .
```

This gives you nice JSON with keys like **path**, **plugin**, **options**, **description**.

---

## 🗂️ Option 2 — Compact table with `column -t`

```bash
vault secrets list -detailed | column -t -s $'\t'
```

This aligns all fields into neat columns.

---

## 📋 Option 3 — Show only important fields

If you only want the essentials:

```bash
vault secrets list -detailed -format=json \
  | jq -r '.[] | [.plugin, .type, .options.version // "n/a", .description] | @tsv' \
  | column -t
```

**Sample output:**

```
kv        secret/    v2   General purpose KV store
kv        secrets/   v2   General purpose KV store
cubbyhole cubbyhole  n/a  Per-token private storage
identity  identity   n/a  Identity store
sys       system     n/a  System endpoints
```

---

## 🎨 Even shorter view

```bash
vault secrets list
```

Just shows:

```
Path         Type      Accessor
----         ----      --------
cubbyhole/   cubbyhole cubbyhole_xxx
identity/    identity  identity_xxx
secret/      kv        kv_xxx
secrets/     kv        kv_xxx
sys/         system    system_xxx
```

---

## ✅ Recommendation (day‑to‑day)

```bash
vault secrets list | column -t
```

Clean, human‑readable alignment for quick checks.
