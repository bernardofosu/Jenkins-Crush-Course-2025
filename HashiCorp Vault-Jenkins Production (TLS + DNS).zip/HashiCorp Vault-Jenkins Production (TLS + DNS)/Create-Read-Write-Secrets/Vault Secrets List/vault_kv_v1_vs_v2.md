# 🔑 KV v1 vs KV v2 in Vault

## 🗂️ KV v1

-   Paths are flat → no versioning.
-   Reads/writes happen directly at `secret/<path>`.

📌 **Example:**

``` bash
vault kv put secret/myapp/config username=admin password=passw0rd
vault kv get secret/myapp/config
```

------------------------------------------------------------------------

## 📚 KV v2

-   Adds versioning of secrets.
-   Internally uses `/data/…` and `/metadata/…`.
-   CLI hides this, API requires it.

📌 **Enable:**

``` bash
vault secrets enable -path=secret kv-v2
```

📌 **Write:**

``` bash
vault kv put secret/myapp/config username=admin password=passw0rd
```

📌 **Read:**

``` bash
vault kv get secret/myapp/config
```

👉 Under the hood, the CLI:

``` bash
vault kv get secret/myapp/config
```

actually calls the API:

``` http
GET /v1/secret/data/myapp/config
```

------------------------------------------------------------------------

## 🌐 When it matters

-   **Using Vault CLI?** Just run `vault kv get/put` → CLI adds `/data/`
    for you.
-   **Calling HTTP API directly?** You must include `/data/`, e.g.

``` http
GET https://vault.example.com/v1/secret/data/myapp/config
```

❌ Forget `/data/` → you'll see *"unsupported path"*.

------------------------------------------------------------------------

## ⚡ TL;DR

-   **KV v1** → `/secret/<path>`\
-   **KV v2** → `/secret/data/<path>` (values),
    `/secret/metadata/<path>` (versions)

CLI hides the difference, API shows it.

------------------------------------------------------------------------

✨ **Pro tip:** Pick a naming convention for your paths (e.g.,
`secret/<team>/<service>/<env>`) to keep secrets tidy and policies
simple.
