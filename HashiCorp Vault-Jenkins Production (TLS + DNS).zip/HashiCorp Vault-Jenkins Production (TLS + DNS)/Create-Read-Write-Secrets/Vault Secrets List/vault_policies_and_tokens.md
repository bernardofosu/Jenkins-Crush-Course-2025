# 🔑 Vault Policies & Tokens

## 📦 Where policies attach

In Vault you can bind a policy at multiple levels: - **Users** → via
login methods like userpass, LDAP, OIDC\
- **Roles** → e.g., AppRole role, Kubernetes role, AWS role (each can
specify policies)\
- **Tokens** → you can directly create a token with specific policies\
- **Root token** → special: bypasses policies entirely, full access

------------------------------------------------------------------------

## 📦 Built-in (default) policies

### 🛡 root policy

-   Attached to the root token you get at `vault operator init`.\
-   Full unrestricted access to everything.\
-   ⚠️ Should be used only for bootstrap, then locked away.

### 🛡 default policy

-   Attached automatically to all tokens (unless removed).\
-   Very minimal --- mainly for token self-management.\
-   Does **not** allow access to secrets.

📌 **Example:** Inspect default policy

``` bash
vault policy read default
```

You'll see something like:

``` hcl
path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

path "sys/health" {
  capabilities = ["read", "sudo"]
}
```

------------------------------------------------------------------------

## 🔑 Token behavior

-   **Token = bearer credential** → whoever holds it can use it.\
-   Vault doesn't ask "who are you?" once a token is issued --- it only
    checks its **policies**.\
-   **Policies** = define permissions.\
-   **Tokens** = carry those policies.

------------------------------------------------------------------------

## 🧩 Example flow

1.  Admin creates a policy **reader**:

``` bash
vault policy write reader - <<EOF
path "secret/data/nakod/*" {
  capabilities = ["read", "list"]
}
EOF
```

2.  Create user with policy:

``` bash
vault auth enable userpass
vault write auth/userpass/users/alice password="S3cret!" policies="reader"
```

3.  Alice logs in → gets a token with `reader` policy.\
4.  With that token:
    -   ✅ Can `vault kv get secret/nakod/github`\
    -   ❌ Cannot `vault kv put secret/nakod/github token=new`

------------------------------------------------------------------------

## ⚡ TL;DR

-   **root policy** → unlimited (bootstrap only).\
-   **default policy** → minimal (token self-management).\
-   **Custom policies** → you create and attach to users, roles, or
    tokens.

✨ Pro tip: Always restrict tokens with **short TTLs** and revoke unused
ones.
