# 🔒 Understanding `umask 077`

## ❓ Great Question!
Short answer: **`umask 077` does not lock files**.  
It only controls the **default permissions** of files/dirs you create from that shell.  

👉 You (and root) can still `chmod` later.  
👉 Others can’t change your files’ perms anyway unless they own the file or have write access to the parent directory.  

---

## 📖 What `umask 077` Really Does
- Applies **per shell/session** (and to child processes).  
- Affects **new items only**.  
- **Effective perms = default perms AND ~umask**  

📝 Regular files:  
```
666 & ~077 → 600 (rw-------)
```  

📂 Directories:  
```
777 & ~077 → 700 (rwx------)
```  

✅ With `umask 077`, your redirect will create `vault-unseal.json` as **600** by default.  
Your `chmod 600` is fine but redundant—it just makes the intent explicit.  

---

## 🛠️ Safer One-Shot Recipe (apply umask only to this write)
```bash
mkdir -p ~/.secrets && chmod 700 ~/.secrets

# Run in a subshell so umask 077 only affects this command
( umask 077
  aws secretsmanager get-secret-value --secret-id vault/unseal-keys   | jq -r '.SecretString | fromjson' > ~/.secrets/vault-unseal.json
)

# Verify permissions
stat -c '%a %n' ~/.secrets/vault-unseal.json   # should show: 600
```

---

## 🔐 Extra Hardening Tips
- Ensure parent directory isn’t writable by others:  
  ```bash
  chmod 700 ~/.secrets
  ```  

- Guarantee mode 600 regardless of umask:  
  ```bash
  install -m 600 /dev/null ~/.secrets/vault-unseal.json
  aws secretsmanager get-secret-value --secret-id vault/unseal-keys   | jq -r '.SecretString | fromjson' > ~/.secrets/vault-unseal.json
  ```  
  (Truncating a file keeps its existing mode.)  

- Avoid exposing secrets on screen/logs:  
  ```bash
  aws secretsmanager get-secret-value --secret-id vault-unseal-keys   | jq -r '.SecretString | fromjson | keys'
  ```  

---

## 🧾 Bottom Line
- `umask 077` gives **secure defaults** → new files = 600, dirs = 700  
- It doesn’t stop later permission changes.  
- Your `chmod 600` is a safe **belt-and-suspenders** practice.  
