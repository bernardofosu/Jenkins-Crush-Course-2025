# 🔐 AWS Secrets in the Console — Yes, You Can View Them (with the right perms)

> TL;DR: **Both** AWS Secrets Manager and SSM Parameter Store can display **decrypted** values in the **console** for identities that have permission.

---

## 🔑 Secrets Manager (UI)
1. **AWS Console → Secrets Manager → Secrets →** select your secret (e.g., `vault/unseal-keys`).
2. Click **Retrieve secret value**.
3. View as **Key/value** or **Plaintext**. You can copy values from the list.
4. Click **Hide secret value** when done.

**Permissions required**
- `secretsmanager:GetSecretValue` on the secret **and**
- `kms:Decrypt` on the KMS key used to encrypt it.

> 📜 **Auditing:** CloudTrail logs `GetSecretValue` events.

---

## 🗂️ Parameter Store (UI)
1. **AWS Console → Systems Manager → Parameter Store →** select the parameter.
2. Toggle **Show decrypted value** to reveal the plaintext.

**Permissions required**
- `ssm:GetParameter` (with `--with-decryption` equivalent)
- `kms:Decrypt` on the KMS key (for `SecureString`).

> ℹ️ Parameter Store has **no scheduled deletion** feature; deletes are immediate.

---

## 🧰 Helpful CLI (pretty print)
```bash
# Secrets Manager
aws secretsmanager get-secret-value --secret-id vault/unseal-keys   --query SecretString --output text | jq .

# Parameter Store (SecureString)
aws ssm get-parameter --name "/vault/unseal-keys" --with-decryption   --query Parameter.Value --output text | jq .
```

---

## 🚧 Best practices
- Limit **console access** and use **least privilege** (grant view only to roles that truly need it).
- Consider a **resource policy** on Secrets Manager secrets to restrict who can call `GetSecretValue`.
- Lock down **KMS key** policy (only allow `kms:Decrypt` to trusted principals).
- Prefer **automation** that fetches secrets at runtime over humans copying values.
