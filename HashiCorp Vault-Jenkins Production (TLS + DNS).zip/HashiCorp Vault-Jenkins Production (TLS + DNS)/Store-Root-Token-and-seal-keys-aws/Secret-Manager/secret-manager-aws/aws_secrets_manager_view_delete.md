# 🔎 Viewing and Deleting Secrets in AWS Secrets Manager

## 🔎 How to View the Value in the Console
1. **AWS Console** → Secrets Manager → Secrets → click `vault/unseal-keys`.  
2. On **Overview**, find **Secret value** → click **Retrieve secret value**.  
   - If you open a specific **Version ID**, there’s also a Retrieve secret value button.  
3. The JSON will be shown (copy if needed).  
4. Click **Hide secret value** when done.  

---

## 🧰 If the Button is Missing / “Not Authorized”
You need **both permissions**:  
- `secretsmanager:GetSecretValue` on that secret  
- `kms:Decrypt` on the KMS key used  

Minimal allow example:  
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["secretsmanager:GetSecretValue"],
    "Resource": "arn:aws:secretsmanager:us-east-1:440744234244:secret:vault/unseal-keys-*"
  },{
    "Effect": "Allow",
    "Action": ["kms:Decrypt"],
    "Resource": "*"
  }]
}
```

*(Restrict KMS ARN if you use a CMK)*  

---

## 🧾 CLI: Pretty Print (safer on screen)
```bash
aws secretsmanager get-secret-value --secret-id vault/unseal-keys   --query SecretString --output text | jq .
```

---

## 🔐 Save Securely (one-liner)
```bash
mkdir -p ~/.secrets && chmod 700 ~/.secrets
( umask 077
  aws secretsmanager get-secret-value --secret-id vault/unseal-keys   --query SecretString --output text | jq . > ~/.secrets/vault-unseal.json
)
```
- `umask 077` makes the new file **600**.  
- Keep parent dir private (`chmod 700 ~/.secrets`).  

---

## 📝 Create/Update via Console or CLI
**Console**: Store a new secret → Other type → Plaintext → paste JSON → choose key → name `vault/unseal-keys`.  

**CLI**:  
```bash
aws secretsmanager create-secret --name vault/unseal-keys   --secret-string file://vault-unseal.json
```

---

## 🗑️ How to Delete a Secret (UI + CLI)

⚠️ These are unseal keys + root token — make an offline backup before deletion.

### 🖱️ UI (Console) — Schedule Deletion
1. AWS Console → Secrets Manager → Secrets → `vault/unseal-keys`  
2. Click **Actions → Delete (Schedule deletion)**  
3. Pick waiting period (🗓️ 7–30 days)  
4. While scheduled, cannot retrieve the secret  
5. To undo: open banner → **Actions → Restore secret**  

### 🧰 CLI — Schedule, Force, Verify, Restore
1) 🗓️ **Schedule deletion (recommended)**  
```bash
aws secretsmanager delete-secret   --secret-id vault/unseal-keys   --recovery-window-in-days 7   --region us-east-1
```

2) ⚡ **Delete immediately (no recovery window)**  
```bash
aws secretsmanager delete-secret   --secret-id vault/unseal-keys   --force-delete-without-recovery   --region us-east-1
```

3) 🔍 **Verify status**  
```bash
aws secretsmanager describe-secret   --secret-id vault/unseal-keys   --region us-east-1   --query '{Name:Name, DeletedDate:DeletedDate, ARN:ARN}'
```

4) ♻️ **Cancel deletion / restore (only during waiting period)**  
```bash
aws secretsmanager restore-secret   --secret-id vault/unseal-keys   --region us-east-1
```

---

## ✅ Permissions Required
- `secretsmanager:DeleteSecret`  
- `secretsmanager:RestoreSecret` (if undo is needed)  

KMS permissions aren’t required to delete the secret, but **don’t delete the CMK** until you’re sure you won’t restore.  

🧠 Tips

Prefer scheduled deletion (7–30 days) for a safety net.

After scheduling, you’ll stop being able to call GetSecretValue on it.

If you created replicas in other regions, delete/schedule deletion for those as well.