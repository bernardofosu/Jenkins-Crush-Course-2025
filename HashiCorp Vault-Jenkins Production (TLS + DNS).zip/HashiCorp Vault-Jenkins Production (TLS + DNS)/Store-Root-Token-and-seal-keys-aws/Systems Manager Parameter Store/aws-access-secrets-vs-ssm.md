# 🔑 Access Patterns — AWS **Secrets Manager** vs **SSM Parameter Store**

You’re right that they *feel* different to access. The short version:
- **Parameter Store** → you always pass a **name** (a hierarchical path like `/vault/unseal-keys`).
- **Secrets Manager** → the CLI flag is `--secret-id`, but the value can be **either the secret’s *name*** *or* its **ARN** (so it’s not strictly “ID-only”).

---

## 🧰 CLI flags & what they accept

| Service | CLI command | Required flag | What the value can be |
|---|---|---|---|
| Secrets Manager 🔐 | `aws secretsmanager get-secret-value` | `--secret-id` | **Secret name** (e.g., `vault/unseal-keys`) **or** **ARN** (`arn:aws:secretsmanager:...:secret:vault/unseal-keys-<suffix>`) |
| Parameter Store 🗂️ | `aws ssm get-parameter` | `--name` | **Parameter name** (hierarchical path), e.g., `/vault/unseal-keys` |

> ✅ In Secrets Manager, `--secret-id` is a *flexible identifier*: name **or** ARN. In Parameter Store, you **must** use the parameter **name**.

---

## 🧾 Versioning differences

- **Secrets Manager**
  - Latest version is labeled **`AWSCURRENT`**.
  - You can target a specific version by **`--version-id`** (GUID) or **`--version-stage`** (label).
  - Example:  
    ```bash
    aws secretsmanager get-secret-value       --secret-id vault/unseal-keys       --version-stage AWSCURRENT       --query SecretString --output text | jq .
    ```

- **Parameter Store**
  - Each update increments an **integer version**.
  - `get-parameter` returns the latest only; to browse versions use **`get-parameter-history`** (or use **labels** you’ve assigned).
  - Example (list history):  
    ```bash
    aws ssm get-parameter-history --name /vault/unseal-keys --with-decryption
    ```

---

## 🔗 Dynamic references (CloudFormation / UserData / SSM docs)

- **Secrets Manager** (name or ARN; optional JSON key & stage):  
  ```
  {{resolve:secretsmanager:vault/unseal-keys:SecretString:UnsealKey1:versionStage:AWSCURRENT}}
  ```

- **Parameter Store** (secure string with explicit version):  
  ```
  {{resolve:ssm-secure:/vault/unseal-keys:1}}
  ```

---

## 🧑‍💻 Quick examples

**Secrets Manager (by name):**
```bash
aws secretsmanager get-secret-value   --secret-id vault/unseal-keys   --query SecretString --output text | jq .
```

**Secrets Manager (by ARN):**
```bash
aws secretsmanager get-secret-value   --secret-id arn:aws:secretsmanager:us-east-1:111122223333:secret:vault/unseal-keys-abc123   --query SecretString --output text | jq .
```

**Parameter Store (by name):**
```bash
aws ssm get-parameter   --name /vault/unseal-keys   --with-decryption   --query 'Parameter.Value' --output text | jq .
```

---

## 🛡️ IAM reminder

- **Secrets Manager**: `secretsmanager:GetSecretValue` **and** `kms:Decrypt` on the key used.
- **Parameter Store**: `ssm:GetParameter` (and `kms:Decrypt` if `SecureString`).

---

## 🧭 When to prefer name vs ARN

- Use **name** for simplicity *within the same account/region*.
- Use **ARN** when:
  - You reference across accounts/regions
  - You need to disambiguate secrets with the same name in different places
  - You lock down policies to a specific secret resource

---

### TL;DR
- **Parameter Store** → *name only* (e.g., `/path/key`).  
- **Secrets Manager** → `--secret-id` accepts **name or ARN**; you can also select by **version stage**/**version id**.
