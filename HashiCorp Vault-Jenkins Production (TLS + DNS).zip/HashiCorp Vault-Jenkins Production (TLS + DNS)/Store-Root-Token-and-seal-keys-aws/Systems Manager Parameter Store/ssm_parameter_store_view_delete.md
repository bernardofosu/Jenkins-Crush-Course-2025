# 🗝️ SSM Parameter Store — View & Delete (SecureString)

## 🔎 View Value (Console)
1. AWS Console → Systems Manager → Parameter Store  
2. Click the parameter (e.g., `/vault/unseal-keys`)  
3. Click **Show (eye icon)** → value appears *(requires KMS decrypt perms)*  
4. Click **Hide** when done  

---

## 🚫 If You See “Not Authorized”
You need both permissions:  
- `ssm:GetParameter` on the parameter  
- `kms:Decrypt` on the KMS key used  

Minimal allow example:  
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["ssm:GetParameter"],
    "Resource": "arn:aws:ssm:us-east-1:440744234244:parameter/vault/unseal-keys"
  },{
    "Effect": "Allow",
    "Action": ["kms:Decrypt"],
    "Resource": "*"   // ideally restrict to the exact CMK ARN
  }]
}
```

---

## 🧾 View with CLI (Pretty Print)
```bash
aws ssm get-parameter   --name "/vault/unseal-keys"   --with-decryption   --query 'Parameter.Value' --output text | jq -r '.'
```

---

## 🔐 Save Securely
```bash
mkdir -p ~/.secrets && chmod 700 ~/.secrets
( umask 077
  aws ssm get-parameter     --name "/vault/unseal-keys"     --with-decryption     --query 'Parameter.Value' --output text   | jq -r '.' > ~/.secrets/vault-unseal.json
)  # file => 600
```

---

## 🗑️ Delete (⚠️ No Recycle Bin!)
- Parameter Store deletion is **immediate** (no recovery window like Secrets Manager).  
- Back up first (export to secure file/S3 with SSE-KMS).  

### 🖱️ Console
1. Systems Manager → Parameter Store → select parameter(s).  
2. **Actions → Delete → confirm**.  
3. Done. *(Re-create manually to “restore”)*  

### 🧰 CLI — Single / Bulk
**Single:**  
```bash
aws ssm delete-parameter --name "/vault/unseal-keys" --region us-east-1
```

**Bulk:**  
```bash
aws ssm delete-parameters --names "/vault/unseal-keys" "/another/param" --region us-east-1
```

**Recursive (entire path):**  
```bash
aws ssm get-parameters-by-path   --path "/vault" --recursive --query 'Parameters[].Name' --output text | tr '\t' '\n' | xargs -n20 aws ssm delete-parameters --region us-east-1 --names
```

---

## 🔍 Verify Deletion
```bash
aws ssm get-parameter --name "/vault/unseal-keys" --with-decryption || echo "✅ Parameter not found (deleted)"
```

Or:  
```bash
aws ssm describe-parameters   --parameter-filters "Key=Name,Option=Equals,Values=/vault/unseal-keys"
```

---

## ✅ Permissions to Delete
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["ssm:DeleteParameter","ssm:DeleteParameters"],
    "Resource": "arn:aws:ssm:us-east-1:440744234244:parameter/vault*"
  }]
}
```
*(KMS perms not needed to delete, but required to read/backup beforehand.)*  

---

## 🧠 Tips
- Prefer **least privilege** → scope IAM Resource to exact parameter ARN.  
- Avoid printing secrets on shared terminals; redact shell history.  
- Use **Parameter Policies** (expiration/notification) to automate clean-ups.  
