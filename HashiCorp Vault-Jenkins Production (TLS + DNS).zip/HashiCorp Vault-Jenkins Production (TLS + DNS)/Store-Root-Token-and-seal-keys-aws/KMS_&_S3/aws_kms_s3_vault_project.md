# 🚀 AWS Project: Securely Storing Vault Keys with KMS + S3

## 🟢 Step 1. Create an IAM User
- Go to **AWS Console → IAM → Users → Create user**.  
- Name it 👉 `vault-kms-s3-admin`.  
- **Attach minimum policies** *(tighten to specific ARNs in prod)*:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    { "Effect": "Allow", "Action": ["s3:*"], "Resource": "*" },
    { "Effect": "Allow", "Action": ["kms:*"], "Resource": "*" }
  ]
}
```
- Create **Access Key + Secret Key** → download `.csv`.  

✅ This user will manage encryption & storage of Vault keys.

---

## 🟢 Step 2. Configure AWS CLI
On your local machine:
```bash
aws configure
```
Fill in:
- Access Key ID  
- Secret Access Key  
- Region → `us-east-1`  
- Output format → `json`  

✅ Now CLI is ready to talk to AWS.

---

## 🟢 Step 3. Create the File
Create a JSON file with Vault unseal keys + root token:
```bash
nano vault-keys.json
```
Paste:
```json
{
  "UnsealKey1": "",
  "UnsealKey2": "",
  "UnsealKey3": "",
  "UnsealKey4": "",
  "UnsealKey5": "",
  "RootToken": ""
}
```
Save & exit.

---

## 🟢 Step 4. Encrypt with AWS KMS
```bash
aws kms encrypt   --key-id alias/my-kms-key   --plaintext fileb://vault-keys.json   --output text   --query CiphertextBlob | base64 --decode > vault-keys.json.enc
```
- Replace `alias/my-kms-key` with your **KMS key alias or ARN**.  
- Output file 👉 `vault-keys.json.enc` = encrypted blob.  

✅ Even if someone steals the file, it’s useless without KMS.

---

## 🟢 Step 5. Upload to S3
```bash
aws s3 cp vault-keys.json.enc s3://my-secure-bucket/vault-keys/
```
✅ File is **encrypted + stored** in S3.

---

## 🟢 Step 6. Decrypt When Needed
```bash
# Download encrypted file
aws s3 cp s3://my-secure-bucket/vault-keys/vault-keys.json.enc .

# Decrypt with KMS
aws kms decrypt   --ciphertext-blob fileb://vault-keys.json.enc   --output text   --query Plaintext | base64 --decode > vault-keys.json
```
Now `vault-keys.json` contains your original secrets again.

⚠️ Requires **both**:
- `s3:GetObject` (S3 read access)  
- `kms:Decrypt` (KMS permission).

---

## 🟢 Step 7. Why Encrypt Before Upload?
🔑 S3 has its own encryption methods, but understanding access matters:

| 🔒 Type | Who Can Read? | Notes |
|---|---|---|
| **SSE-S3 (default)** | Anyone with `s3:GetObject` | Transparent decryption ✅ |
| **SSE-KMS** | Needs `s3:GetObject` **and** `kms:Decrypt` | Safer 🔒 |
| **SSE-C (customer key)** | Must supply key each GET | Rarely used 🔐 |
| **Client-side KMS (our method)** | Must have the ciphertext **and** `kms:Decrypt` | Double lock 🔒🔒 |

✅ Our method ensures:  
- Even if the S3 bucket is misconfigured → the object is still ciphertext.  
- Only trusted admins with **both S3 + KMS** access can read it.

---

## 🟢 Step 8. IAM Best Practices
- ✅ **Separate duties**:
  - Role A → Upload only (no `kms:Decrypt`).  
  - Role B → Decrypt only.  
- ✅ Enable **MFA** on IAM users.  
- ✅ Use **bucket policies** + **KMS key policies** to restrict who can decrypt.  
- ✅ Never hardcode AWS keys in apps.

---

## 🎯 Final Takeaways
- 🔐 Use **AWS KMS + S3** to store Vault unseal keys & root token safely.  
- 🛡️ Adds an **extra layer** of security beyond S3’s built‑in encryption.  
- 👤 Only users with **both S3 + KMS** permissions can recover the file.  
- 📦 This method is ideal for **critical secrets like Vault unseal keys**.

---

## 🗺️ Optional Diagram (Text)
```
📄 vault-keys.json
   ↓ 🔑 KMS Encrypt (alias/my-kms-key)
🧱 vault-keys.json.enc (ciphertext)
   ↓ ☁️ Upload to S3 (s3://my-secure-bucket/vault-keys/)
👤 Admin with s3:GetObject + kms:Decrypt
   ↓ 🔑 KMS Decrypt
📄 vault-keys.json (plaintext recovered)
```
