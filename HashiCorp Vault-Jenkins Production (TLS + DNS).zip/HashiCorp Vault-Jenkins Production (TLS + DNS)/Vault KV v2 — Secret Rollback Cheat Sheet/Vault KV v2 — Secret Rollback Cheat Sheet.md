# 🔄 Vault KV v2 — Secret Rollback Cheat Sheet

Versioned secrets = easy rollbacks. Here’s the quick, safe flow.

---

## 1) 🔍 Check available versions

```bash
vault kv metadata get secret/app
```

*Shows current/past versions, timestamps, deletion status.*

---

## 2) 📖 Read an older version

```bash
vault kv get -version=1 secret/app
```

*Confirm the exact data you want to restore.*

---

## 3) ♻️ Restore (make it the latest)

```bash
# Re‑write the old values as the new version
vault kv put secret/app username=alice password=1111
```

*This creates a new version (e.g., v3) containing the restored data.*

---

## 4) 🧱 Prevent accidental overwrites (CAS)

```bash
# Only update if the current latest is still version 2
vault kv put -cas=2 secret/app username=alice password=1111
```

**CAS = Check‑And‑Set** → blocks the write if someone updated it meanwhile.

---

## 5) 🗂️ Undelete or 🔥 Destroy specific versions

```bash
# Undelete a previously deleted version
vault kv undelete -versions=2 secret/app

# Permanently destroy a version (irreversible)
vault kv destroy -versions=2 secret/app
```

---

## ✅ TL;DR

* KV v2 keeps **versions** → you can roll back by **reading an old version** and **writing it back**.
* Use **CAS** to avoid race conditions.
* Use **undelete/destroy** to manage historical versions explicitly.

---

### 🧠 Pro tips

* Separate paths per **env/app**: `secret/prod/app1/db` vs `secret/dev/app1/db`.
* Add a small wrapper (script/CI step) that always uses **`-cas=$(current_version)`**.
* Audit: `vault audit` + `vault kv metadata get` to track who changed what and when.
