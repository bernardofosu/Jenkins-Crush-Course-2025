# 🔑 `vault secrets enable -path=secret kv-v2` — Explained

## ✅ What it does
Enables (mounts) a secrets engine of type **Key/Value v2** at the mount path **`secret/`**.  
After this, anything you **write/read** under `secret/...` uses **KV v2**, which supports **versioning**, **undelete**, and **permanent destroy**. ✨

---

## 🆚 Why KV v2 (vs v1)?
- **v1:** simple K/V, **no versions**.  
- **v2:** keeps **versions** of each secret, lets you **soft‑delete**, **undelete**, **destroy specific versions**, and use **check‑and‑set (CAS)** to prevent accidental overwrites. 🛡️

---

## 🧪 Quick usage (CLI)
```bash
# write (creates version 1, then 2, etc.)
vault kv put secret/myapp username=admin password=supersecure123

# read (returns latest version by default)
vault kv get secret/myapp

# list keys under a folder
vault kv list secret/

# soft-delete version(s)
vault kv delete -versions=2 secret/myapp

# undelete version(s)
vault kv undelete -versions=2 secret/myapp

# permanently destroy version(s)
vault kv destroy -versions=2 secret/myapp

# delete ALL versions + metadata (irrevocable)
vault kv metadata delete secret/myapp
```

---

## 🔧 Under the hood (API paths)
For a mount at `secret/` with **KV v2**:
- **Write/Read data:** `/v1/secret/data/<path>`  
- **Metadata ops:** `/v1/secret/metadata/<path>`

**Example (HTTP):**
```bash
# write
curl -s -H "X-Vault-Token: $VAULT_TOKEN"   -H "Content-Type: application/json"   -X POST   --data '{"data":{"username":"admin","password":"supersecure123"}}'   "$VAULT_ADDR/v1/secret/data/myapp"

# read
curl -s -H "X-Vault-Token: $VAULT_TOKEN"   "$VAULT_ADDR/v1/secret/data/myapp"
```

---

## 🔐 Policies for KV v2 (common gotcha)
KV v2 uses **different paths** in policies:

```hcl
# read/create/update/delete secret data
path "secret/data/*" {
  capabilities = ["create", "update", "read", "delete"]
}

# list, delete metadata, destroy all versions
path "secret/metadata/*" {
  capabilities = ["list", "read", "delete", "update"]
}
```

> ⚠️ If you grant only `secret/*` like v1, reads will fail — use **`secret/data/*`** and **`secret/metadata/*`**.

---

## 🧰 Common errors & tips
- **“pre-existing mount at secret/”** → you already have something mounted there. Check:
  ```bash
  vault secrets list -detailed
  ```
  Either pick another path (e.g., `-path=internal`) or disable the current mount:
  ```bash
  vault secrets disable secret/
  ```
- **Reading the wrong path** (v2 needs `/data/...`). Use `vault kv ...` CLI to avoid path mistakes.

Equivalent command (many versions):
```bash
vault secrets enable -path=secret -version=2 kv
```
…but `kv-v2` is the clearest. ✅

---

## 🎯 TL;DR
You’ve mounted a **versioned** secret store at **`secret/`**. Use `vault kv` commands for safe, version‑aware secret operations. 🚀
