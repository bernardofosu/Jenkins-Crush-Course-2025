# 🔐 Vault Token & KV v2 Metadata — Quick Guide

## 🧾 Token Fields (Root Token Example)

- **token_accessor:** `8THnOhaFU1mSOdg56siB4onc`  
  🔎 A short, non-sensitive handle for the token. You can **look up or revoke** a token with the accessor **without knowing the full token value**.  
  - Lookup: `vault token lookup -accessor 8THnOhaFU1mSOdg56siB4onc`  
  - Revoke: `vault token revoke -accessor 8THnOhaFU1mSOdg56siB4onc`  
  ❗ The accessor **cannot** be used to authenticate to Vault.

- **token_duration:** `∞`  
  ⏳ The token has **no TTL** (it never expires on its own). Root tokens commonly show this. They live until **explicitly revoked**. High risk if leaked.

- **token_renewable:** `false`  
  🔄 You **cannot** extend this token’s lifetime with `vault token renew`. (Not needed anyway if duration is infinite.)

- **token_policies / policies:** `["root"]`  
  🛠️ The token has the **root policy**, which grants **full access to everything**. Intended only for **bootstrap** and **emergencies**.

- **identity_policies:** `[]`  
  👤 No extra policies from an Identity entity/group (OIDC, userpass, etc.). This is a standalone token.

---

## ✅ What to do next (Best Practice)

- 🔐 **Use root only to bootstrap**, then switch to least-privilege admin tokens.

```bash
# Example: create an admin policy and a short-lived admin token
vault policy write admin - <<'HCL'
path "*" { capabilities = ["create","read","update","delete","list","sudo"] }
HCL

vault token create -policy=admin -ttl=1h
```

- ⏱️ **Lock down token lifetimes**: prefer finite TTL and (for operators) renewable tokens you can rotate.  
- ❌ **Revoke the root token** once setup is finished (or store it offline and use “generate-root” when needed).

```bash
# If you still have the token string:
vault token revoke <root-token>

# Or with just the accessor you showed:
vault token revoke -accessor 8THnOhaFU1mSOdg56siB4onc
```

> 🧠 **TL;DR:** This is a **root token** with **no expiry**, **not renewable**, and **full power**. Keep it **offline**, use sparingly, operate day‑to‑day with **scoped, time‑limited** tokens.

---

## 📦 KV v2 — Secret Metadata Example

**== Secret Path ==**  
`secret/data/myapp`

**======= Metadata =======**  
| Key             | Value                                      |
|-----------------|--------------------------------------------|
| created_time    | 2025-09-15T17:21:17.991829263Z             |
| custom_metadata | `<nil>`                                    |
| deletion_time   | n/a                                        |
| destroyed       | false                                      |
| version         | 1                                          |

### 🧠 What this means
- 📍 **Secret Path:** `secret/data/myapp` → KV v2 API path. `vault kv get secret/myapp` calls `/v1/secret/data/myapp` under the hood.  
- 🕒 **created_time:** when version **1** was written (UTC).  
- 🏷️ **custom_metadata:** none set yet (you can add tags/labels).  
- 🗑️ **deletion_time:** _n/a_ → not soft-deleted.  
- 💣 **destroyed:** `false` → not permanently destroyed.  
- 🔢 **version:** `1` → first (current) version; each write bumps this.

### 🛠️ Handy commands
```bash
# write a new version (becomes v2)
vault kv put secret/myapp username=admin2 password=changeMe

# see metadata & versions
vault kv metadata get secret/myapp

# add custom metadata
vault kv metadata put -custom-metadata owner=dev team=platform secret/myapp

# soft-delete version 1 (can be undeleted)
vault kv delete -versions=1 secret/myapp

# undelete version 1
vault kv undelete -versions=1 secret/myapp

# permanently destroy version 1
vault kv destroy -versions=1 secret/myapp

# CAS: only write if current version is 1 (prevent overwrite)
vault kv put -cas=1 secret/myapp username=admin3
```
