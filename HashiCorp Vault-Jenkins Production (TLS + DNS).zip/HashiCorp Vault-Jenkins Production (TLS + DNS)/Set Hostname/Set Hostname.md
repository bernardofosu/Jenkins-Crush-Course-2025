# 🖥️ Set Hostname — Quick Guide

Make your machine’s name consistent across reboots + tools. Copy/paste for your OS.

---

## 🐧 Linux (systemd: Ubuntu/Debian/RHEL/CentOS/Amazon Linux)

```bash
# 👀 View current
hostnamectl

# ✏️ Set new hostname (persistent, no reboot)
sudo hostnamectl set-hostname myserver --static

/bin/bash

# 🏷️ Optional: pretty name (human‑friendly)
sudo hostnamectl set-hostname "My Server" --pretty

# 📌 Ensure FQDN resolution locally (optional but useful)
echo "127.0.1.1  myserver" | sudo tee -a /etc/hosts

# ✅ Verify
hostnamectl; echo "short:" $(hostname); echo "fqdn:" $(hostname -f)
```

> 🔎 **Tips**
>
> * Use lowercase, no spaces. For FQDN: `host.domain.tld` (e.g., `app01.example.com`).
> * `--static` writes to `/etc/hostname` and is what most services use.

---

## 🐧 Older Linux (no systemd)

```bash
# ⏳ Temporary (until reboot)
sudo hostname myserver

# ♻️ Persistent
echo myserver | sudo tee /etc/hostname
echo "127.0.1.1  myserver" | sudo tee -a /etc/hosts
```

---

## 🍏 macOS

```bash
# 🖥️ GUI name
displayname="My Mac"; sudo scutil --set ComputerName "$displayname"
# 🌐 DNS name (what `hostname` shows)
sudo scutil --set HostName mymac
# 📶 Bonjour (.local)
sudo scutil --set LocalHostName mymac
```

> 📝 **Note**: You can use `scutil --get HostName` to verify.

---

## 🪟 Windows (PowerShell as Admin)

```powershell
# 🔁 Renames and restarts
Rename-Computer -NewName "MYSERVER" -Restart
```

---

## ☁️ Cloud VMs that use cloud-init

Cloud-init can overwrite hostnames on reboot. To preserve yours:

```bash
# 🛡️ Prevent cloud-init from changing the hostname
sudoedit /etc/cloud/cloud.cfg
# set or ensure:
preserve_hostname: true
```

Then re-run your hostname commands above.

---

## ✅ Post-change checklist

* 🔁 **Re-login** or restart terminal to see prompts update.
* 🧩 **SSH banners / prompts** show the new hostname.
* 🧪 `ping $(hostname -f)` works locally if `/etc/hosts` has your mapping.
* 🧭 Update **DNS** if others must resolve `myserver.example.com`.

---

## 🩺 Troubleshooting

* `hostname -f` empty → add an entry in `/etc/hosts`, e.g.:

  ```
  127.0.1.1  myserver myserver.localdomain
  ```
* Services still show old name → restart the service or reboot.
* On containers: hostnames are per‑container; set with `--hostname` at `docker run`.

---

### 🧠 Naming tips

* Use a scheme: `role-env-idx` → `web-prod-01`, `db-stg-02`.
* Keep it short, DNS‑safe (a–z, 0–9, `-`).
