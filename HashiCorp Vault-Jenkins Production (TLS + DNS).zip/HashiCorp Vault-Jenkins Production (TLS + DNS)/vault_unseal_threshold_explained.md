# 🔐 Vault Unseal Threshold (3-of-5) Explained

**Vault doesn’t “need” 3 keys — you told it to** with `-key-threshold=3`.

That flag sets a **Shamir’s Secret Sharing** threshold: **M-of-N**. With `-key-shares=5 -key-threshold=3`, Vault splits its master key into **5 shares** and requires **any 3** to reconstruct it and **unseal**.

---

## ❓ Why pick a minimum of 3 (the threshold)?

- 👥 **Multi‑person control (security):** No single admin can unseal the system. At least 3 distinct custodians must cooperate → reduces insider risk.  
- 🧱 **Redundancy:** You can lose up to **N−M = 2** shares and still recover (**3‑of‑5** tolerates 2 lost shares).  
- 🛡️ **Compromise resistance:** 1 or 2 stolen shares are useless; an attacker needs **3** to reconstruct the master key.  
- ⚖️ **Operational balance:**  
  - `1-of-5` → convenient but weak (one person can unseal).  
  - `5-of-5` → very strong but brittle (lose one share = locked out).  
  - `3-of-5` is a common **sweet spot** between security and recoverability.

---

## 🔁 Change later if you need to

You can **reconfigure the scheme** without reinitializing:

```bash
# start a rekey operation (example: move to 4-of-6)
vault operator rekey -init -key-shares=6 -key-threshold=4

# then provide the current threshold number of existing shares to complete
vault operator rekey
```

---

## 🤖 Note on Auto‑Unseal

If you later enable **AWS KMS auto‑unseal**, these Shamir keys become **recovery keys** (used only for disaster recovery), and **Vault unseals automatically** on restart.

---

## ✨ TL;DR

The **“minimum of 3 keys”** exists because you chose a **3‑of‑5 threshold** — it enforces **multi‑person control** while allowing up to **two lost shares** without losing access.
