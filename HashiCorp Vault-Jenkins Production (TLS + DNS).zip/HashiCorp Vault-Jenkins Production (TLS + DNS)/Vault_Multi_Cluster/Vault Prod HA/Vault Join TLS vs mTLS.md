# 🔐 Vault Join: TLS vs mTLS — Emoji Cheat Sheet

## ⚡ Quick decision

* **Server TLS only (Let’s Encrypt on leader):**

  * Fill **Leader API Address** only (e.g., `https://vault-leader.nakodtech.xyz:8200`).
  * Leave **Leader CA Certificate / Leader Client Certificate / Leader Client Key** **empty** (OS already trusts LE).
* **mTLS (hardened prod):**

  * Provide **all three** cert fields. Details below. ✅

---

## 🧩 What the 3 fields mean (in the follower “Join” UI)

* **Leader CA Certificate** 🏛️

  * CA used by the follower to **verify the leader’s server cert**.
  * If leader uses a **public CA** (Let’s Encrypt), follower already trusts it → **can leave blank**.
  * To be explicit, paste the **CA chain** (from `fullchain.pem`, excluding the leaf), or your **internal CA**.
* **Leader Client Certificate** 🪪

  * The **client cert** presented by the follower to the leader (for **mutual TLS**). Not LE-issued; use your **own CA**.
* **Leader Client Key** 🔑

  * Private key that pairs with the follower’s client cert.

> 🔐 If you enable mTLS on the leader, configure a **client-trust CA** on the leader so it can verify follower client certs.

---

## ✅ Server TLS only (most setups with Let’s Encrypt)

1. On follower UI, set **Leader API Address** to:

   * `https://vault-leader.nakodtech.xyz:8200`
2. Leave the **three cert fields empty**.
3. Click **Join**, then **unseal** the follower using the leader’s unseal keys (same shares).

---

## 🛡️ mTLS (recommended for hardened prod)

You need:

* A **CA** to issue follower **client** certificates (Vault PKI or OpenSSL).
* On **leader**, set `tls_client_ca_file` to trust that CA.
* On **follower**, paste the **client cert** and **key** (and CA if leader uses a private CA).

### A) 📜 Use **Vault PKI** to issue client certs (easiest hardened path)

Do this on the **leader** (after init & unseal):

```bash
# Enable a small internal CA for node mTLS
vault secrets enable pki
vault secrets tune -max-lease-ttl=87600h pki
vault write pki/root/generate/internal \
  common_name="vault-nodes-ca.nakodtech.xyz" ttl=87600h

# Allow issuing certs for node hostnames
vault write pki/roles/vault-nodes \
  allow_any_name=true \
  max_ttl=8760h

# Issue a follower client cert (returns cert, private_key, issuing_ca)
vault write pki/issue/vault-nodes \
  common_name="vault-node1.nakodtech.xyz" ttl=8760h \
  > follower-client.json

# Extract PEMs
jq -r .data.certificate    follower-client.json > follower-client.crt
jq -r .data.private_key    follower-client.json > follower-client.key
jq -r .data.issuing_ca     follower-client.json > follower-ca.pem
```

**Configure the leader listener to require client certs**

```hcl
# /etc/vault.d/vault.hcl
listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/vault.crt"   # LE server cert
  tls_key_file    = "/etc/vault.d/vault.key"   # LE server key

  # mTLS: trust the CA that issued followers' client certs (Vault PKI root)
  tls_client_ca_file = "/etc/vault.d/vault-nodes-ca.pem"
}
```

Copy the CA to the leader and restart:

```bash
sudo cp follower-ca.pem /etc/vault.d/vault-nodes-ca.pem
sudo chown vault:vault /etc/vault.d/vault-nodes-ca.pem
sudo chmod 644 /etc/vault.d/vault-nodes-ca.pem
sudo systemctl restart vault
```

**Fill the follower “Join” form**

* **Leader API Address:** `https://vault-leader.nakodtech.xyz:8200`
* **Leader CA Certificate:** *(optional if using LE)* Paste CA chain or leave blank.
* **Leader Client Certificate:** paste `follower-client.crt`
* **Leader Client Key:** paste `follower-client.key`
* **Join**, then **unseal** the follower.

### B) 🔧 Alternative: **OpenSSL** quick CA (lab/testing)

```bash
# Create a small CA
openssl genrsa -out nodes-ca.key 4096
openssl req -x509 -new -nodes -key nodes-ca.key -sha256 -days 3650 \
  -subj "/CN=vault-nodes-ca.nakodtech.xyz" -out nodes-ca.crt

# Create follower client key/csr
openssl genrsa -out follower-client.key 2048
openssl req -new -key follower-client.key \
  -subj "/CN=vault-node1.nakodtech.xyz" -out follower-client.csr

# Sign client cert with your CA
openssl x509 -req -in follower-client.csr -CA nodes-ca.crt -CAkey nodes-ca.key \
  -CAcreateserial -out follower-client.crt -days 825 -sha256
```

On the **leader**, trust this CA:

```hcl
listener "tcp" {
  # ... your tls_cert_file / tls_key_file ...
  tls_client_ca_file = "/etc/vault.d/nodes-ca.crt"
}
```

Restart Vault, then on the **follower**:

* **Leader API Address:** `https://vault-leader.nakodtech.xyz:8200`
* **Leader CA Certificate:** *(required if leader uses a private CA)*
* **Leader Client Certificate:** `follower-client.crt`
* **Leader Client Key:** `follower-client.key`

---

## 🧪 TL;DR

* 🌍 **Public domain + Let’s Encrypt (server TLS only):** Fill **Leader API Address**, leave the three cert fields **blank**. ✔️
* 🛡️ **mTLS:**

  * On **leader**, set `tls_client_ca_file` to a CA you control (Vault PKI/OpenSSL).
  * On **follower**, paste **client cert** + **key** issued by that CA, and **Leader CA** if the leader doesn’t use a public CA.
