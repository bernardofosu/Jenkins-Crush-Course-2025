# 🟢 Vault 2-Node Cluster Setup (Leader + Follower)

---

## 🟢 Step 1. Do this on **both servers** (Leader & Node)
[**Use Official Vault Package**](https://developer.hashicorp.com/vault/install)
```bash
# Update & install Vault
sudo apt update && sudo apt install -y apt-transport-https gnupg
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main"  | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install -y vault

# Make data dir
sudo mkdir -p /opt/vault/data
sudo chown -R vault:vault /opt/vault
```

---

## 🟢 Step 2. Configure the **Leader**  
(Example: private IP `172.31.10.11`, DNS `vault-1.internal.nakodtech`)

**/etc/vault.d/vault.hcl**
```hcl
storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-leader"
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/vault.crt"
  tls_key_file    = "/etc/vault.d/vault.key"
}

ui = true
disable_mlock = true

api_addr     = "https://vault-1.internal.nakodtech:8200"
cluster_addr = "https://172.31.10.11:8201"
```

**Start Vault**
```bash
sudo systemctl enable vault
sudo systemctl restart vault
```

**Initialize & unseal (only on leader)**
```bash
export VAULT_ADDR="https://vault-1.internal.nakodtech:8200"
vault operator init -key-shares=5 -key-threshold=3 > ~/vault_init.txt
vault operator unseal   # run 3 times with 3 different keys
```

---

## 🟢 Step 3. Configure the **Second Node**  
(Example: private IP `172.31.10.12`, DNS `vault-2.internal.nakodtech`)

**/etc/vault.d/vault.hcl**
```hcl
storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-node-2"

  retry_join {
    leader_api_addr = "https://vault-1.internal.nakodtech:8200"
  }
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/vault.crt"
  tls_key_file    = "/etc/vault.d/vault.key"
}

ui = true
disable_mlock = true

api_addr     = "https://vault-2.internal.nakodtech:8200"
cluster_addr = "https://172.31.10.12:8201"
```

**Start Vault**
```bash
sudo systemctl enable vault
sudo systemctl restart vault
```

**Join cluster**
```bash
export VAULT_ADDR="https://vault-2.internal.nakodtech:8200"
vault operator raft join https://vault-1.internal.nakodtech:8200
```

**Unseal with the same 3 keys from leader**
```bash
vault operator unseal
vault operator unseal
vault operator unseal
```

---

## 🟢 Step 4. Verify Cluster (from leader)
```bash
export VAULT_ADDR="https://vault-1.internal.nakodtech:8200"
vault operator raft list-peers
```

✅ You should see **2 peers**:
- `vault-leader` (Leader)
- `vault-node-2` (Follower / Standby)

---

# 🤔 Why add a second node?

🔑 **Purposes of a follower node**:
- **High Availability (HA):** if leader dies, follower can take over.  
- **Redundancy:** data replicated across both nodes.  
- **Scalability of reads:** followers can answer some queries.  
- **Rolling upgrades:** upgrade one node while the other stays online.  

⚠️ **Caution:**  
With 2 nodes, quorum = 2. Both must be online for leader election.  
For true fault tolerance, use **3 nodes** → quorum = 2, can survive 1 node failure.  

---

✨ In summary:  
- With 1 node → total downtime if it fails.  
- With 2 nodes → replication + HA learning.  
- With 3 nodes → production-ready HA cluster 🚀  
