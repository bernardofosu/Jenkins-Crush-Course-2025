# 🏗️ HashiCorp Vault HA on AWS (TLS + DNS + Raft Storage)

**Goal:** Deploy a production-ready, highly available Vault cluster on AWS EC2 with integrated **Raft** storage, secured by **TLS (Let’s Encrypt)**, accessible via your domain (**nakodtech.xyz**).

[Set Hostname](../../Set%20Hostname/Set%20Hostname.md): Its very Important especially when you are setting up High Availabilty Vault

## 1️⃣ DNS Setup (Spaceship or Any Registrar)

Create the following DNS records for your domain (**nakodtech.xyz**):

| Host           | Type  | Value (example)            | TTL |
|----------------|-------|----------------------------|-----|
| `vault-leader` | A     | `<EC2-Leader-PublicIP>`    | 5m  |
| `vault-node1`  | A     | `<EC2-Node1-PublicIP>`     | 5m  |
| `vault-node2`  | A     | `<EC2-Node2-PublicIP>`     | 5m  |
| `@`            | A     | `<Static Website/GitHub>`  | 30m |
| `www`          | CNAME | `nakodtech.xyz`            | 30m |

👉 Use **private IPs** for cluster communication (**8201/tcp**). DNS is only for **public access** (**8200/tcp**).

---

## 2️⃣ AWS Security Group (SG)

Create a **Vault-SG** and allow:

- **80/tcp** (for Certbot TLS validation)
- **8200/tcp** (Vault API/UI → restrict to admins or ALB)
- **8201/tcp** (Vault cluster communication → private VPC only)

```sh
# Example AWS CLI
aws ec2 create-security-group --group-name Vault-SG --description "Vault Cluster SG"

aws ec2 authorize-security-group-ingress   --group-name Vault-SG --protocol tcp --port 80 --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress   --group-name Vault-SG --protocol tcp --port 8200 --cidr YOUR_ADMIN_IP/32

aws ec2 authorize-security-group-ingress   --group-name Vault-SG --protocol tcp --port 8201 --cidr VPC_CIDR
```

---

## 3️⃣ AWS EC2 Instances

- Launch **3 Ubuntu 22.04 EC2 instances** (`t3.small` or larger).
- Attach **Vault-SG**.
- Assign **Elastic IPs** (for stability).
- Tag instances: `Vault-Leader`, `Vault-Node1`, `Vault-Node2`.

---

## 4️⃣ Install Vault

On **each** instance:
[**Use Official Vault Package**](https://developer.hashicorp.com/vault/install)
```sh
sudo apt update && sudo apt upgrade -y
sudo apt install -y unzip curl jq gnupg snapd

# Install Vault
curl -fsSL https://apt.releases.hashicorp.com/gpg   | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg

echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list

sudo apt update && sudo apt install -y vault
```

---

## 5️⃣ Create Vault User & Directories

```sh
sudo useradd --system --home /etc/vault.d --shell /bin/false vault
sudo mkdir -p /opt/vault/data
sudo mkdir -p /etc/vault.d
sudo chown -R vault:vault /opt/vault /etc/vault.d
```

---

## 6️⃣ TLS Certificates (Let’s Encrypt)

On **each node**, request a cert for its hostname:

```sh
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Example for leader
sudo certbot certonly --standalone -d vault-leader.nakodtech.xyz
```

**Resulting files:**

```
/etc/letsencrypt/live/vault-leader.nakodtech.xyz/fullchain.pem
/etc/letsencrypt/live/vault-leader.nakodtech.xyz/privkey.pem
```

Copy into Vault dir with correct perms:

```sh
sudo cp /etc/letsencrypt/live/vault-leader.nakodtech.xyz/fullchain.pem /etc/vault.d/vault.crt
sudo cp /etc/letsencrypt/live/vault-leader.nakodtech.xyz/privkey.pem   /etc/vault.d/vault.key
sudo chown vault:vault /etc/vault.d/vault.*
sudo chmod 640 /etc/vault.d/vault.key
sudo chmod 644 /etc/vault.d/vault.crt
```

Repeat for **vault-node1** and **vault-node2**.

---

## 7️⃣ Vault Configuration (Raft)

### Leader `/etc/vault.d/vault.hcl`
```hcl
ui = true
disable_mlock = true

storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-leader"
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/vault.crt"
  tls_key_file    = "/etc/vault.d/vault.key"
}

api_addr     = "https://vault-leader.nakodtech.xyz:8200"
cluster_addr = "https://172.31.17.74:8201"
```

### Follower `/etc/vault.d/vault.hcl`
```hcl
ui = true
disable_mlock = true

storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-node1"

  retry_join {
    leader_api_addr = "https://vault-leader.nakodtech.xyz:8200"
  }
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/vault.crt"
  tls_key_file    = "/etc/vault.d/vault.key"
}

api_addr     = "https://vault-node1.nakodtech.xyz:8200"
cluster_addr = "https://172.31.30.121:8201"
```

---

## 8️⃣ Systemd Service

Create `/etc/systemd/system/vault.service`:

```ini
[Unit]
Description=Vault Server
Requires=network-online.target
After=network-online.target

[Service]
User=vault
Group=vault
ExecStart=/usr/bin/vault server -config=/etc/vault.d/vault.hcl
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=on-failure
LimitNOFILE=65536
LimitMEMLOCK=infinity
AmbientCapabilities=CAP_IPC_LOCK
CapabilityBoundingSet=CAP_SYSLOG CAP_IPC_LOCK

[Install]
WantedBy=multi-user.target
```

Enable service:

```sh
sudo systemctl daemon-reexec
sudo systemctl enable vault
sudo systemctl start vault
```

---

## 9️⃣ Initialize Cluster (Leader only)

```sh
export VAULT_ADDR="https://vault-leader.nakodtech.xyz:8200"

vault operator init -key-shares=5 -key-threshold=3 > ~/vault_init.txt
vault operator unseal
vault operator unseal
vault operator unseal
```

👉 Followers **do not** run init. They’ll join via Raft.

---

## 🔟 Join Followers

On follower(s):

```sh
export VAULT_ADDR="https://vault-node1.nakodtech.xyz:8200"

vault operator raft join https://vault-leader.nakodtech.xyz:8200
vault operator unseal
vault operator unseal
vault operator unseal
```

---

## 1️⃣1️⃣ Verify Cluster

On leader:

```sh
vault operator raft list-peers
```

You should see:
- `vault-leader` (**active**)
- `vault-node1` (**standby**)
- `vault-node2` (**standby**)

---

## 1️⃣2️⃣ Test Secret Replication

On leader:
```sh
vault kv put secret/app username=alice password=12345
```

On follower:
```sh
vault kv get secret/app
```

✅ Same secret → replication works 🎉

---

## 1️⃣3️⃣ Auto-Renew TLS

Add to `crontab -e`:
```cron
0 3 * * * certbot renew --post-hook "systemctl restart vault"
```

---

## ✅ Wrap Up

You now have:
- **3-node Vault HA cluster** with **Raft** backend  
- Secured with **TLS (Let’s Encrypt)**  
- Accessible via **DNS** (`vault-leader.nakodtech.xyz`)  
- Secrets replicated across all nodes  
