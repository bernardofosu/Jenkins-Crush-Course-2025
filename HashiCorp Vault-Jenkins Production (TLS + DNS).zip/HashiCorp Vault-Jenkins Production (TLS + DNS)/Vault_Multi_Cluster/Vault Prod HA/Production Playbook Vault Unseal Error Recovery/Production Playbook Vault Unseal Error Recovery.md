# 🛡️ Production Playbook: Vault Unseal / Error Recovery

---

### 1️⃣ Freeze & Capture Evidence

* 🚫 Stop client writes (disable apps, drain LB).
* 📜 Capture logs:

  ```bash
  journalctl -xeu vault -n 500
  vault status
  ```
* 🧪 Confirm config:

  ```bash
  cat /etc/vault.d/vault.hcl
  ```

---

### 2️⃣ Back Up Before Touching Anything

* 📦 **Raft snapshot** (on leader):

  ```bash
  export VAULT_ADDR="https://<leader>:8200"
  vault operator raft snapshot save /tmp/vault.snap
  ```

  Copy `/tmp/vault.snap` off the node.
* 💾 **File storage**: take filesystem/VM snapshot (EBS/LVM/VM).

---

### 3️⃣ Check the 3 Big Mismatches

* 🔐 **Seal method drift** → Ensure `seal "awskms"` is present if used, or none if Shamir.
* 💾 **Storage drift** → Backend (`raft` vs `file`) & `path` must match data.
* 🔑 **Wrong unseal keys** → Use the **exact T-of-N keys** from this cluster.

---

### 4️⃣ Least-Risk Recoveries

* ✅ If Raft & config correct → unseal with shares or let KMS auto-unseal.
* 🔁 If peer is bad but cluster healthy → remove & rejoin:

  ```bash
  vault operator raft list-peers
  vault operator raft remove-peer -peer-id <bad-peer-id>
  ```

  Rebuild node with empty data dir, then join again.
* ♻️ If leader storage corrupt but snapshot available → restore:

  ```bash
  vault operator raft snapshot restore -force /path/to/vault.snap
  ```

---

### 5️⃣ If Recovery Fails → Controlled Restore

* 📂 Restore from last known-good snapshot (Raft) or filesystem snapshot (File).
* ⚙️ Keep the same **seal + storage settings** used originally.

---

### 6️⃣ Post-Incident Hardening

* 🔑 Enable auto-unseal (AWS KMS / HSM).
* 📦 Automate raft snapshots:

  ```bash
  vault operator raft snapshot save /backups/vault-$(date +%F-%H%M).snap
  ```
* 📐 Lock config drift with IaC + code review.
* 🧪 Keep nodes on same Vault version.
* 🧾 Enable audit devices for forensics.
* 🚦 Add health checks + alerts on seal state, leader, Raft lag.

---

### ✅ Quick Do / Don’t

* ✅ **Do**: snapshot first, confirm seal/storage match, restore carefully.
* ❌ **Don’t**: re-init, switch seal/storage live, or delete `/opt/vault/data` in prod.
