# 🔑 Shamir’s Secret Sharing (SSS)

Shamir’s Secret Sharing is a **cryptographic key-splitting scheme**, invented in **1979** by **Adi Shamir** (the “S” in RSA). He created it to solve a real-world security problem: *how to protect a critical secret (like a nuclear launch code or cryptographic master key) without putting it all in the hands of one person.*

By splitting a secret among multiple parties, you prevent a single point of failure and enforce **collaboration and trust**.

---

## 📖 How It Works

* You have one **master secret** (e.g., Vault’s unseal key).
* You split it into **N shares**.
* You define a **threshold T** (e.g., 3 of 5).
* Any **T out of N shares** can reconstruct the secret.
* Fewer than T shares reveal **nothing**.

This relies on **polynomial interpolation (Lagrange over finite fields)**, not hashing or encryption.

---

## 🚫 What Shamir is NOT

* ❌ **Not hashing** (e.g., SHA‑256).
* ❌ **Not encryption** (e.g., AES).
* ✅ It’s **secret splitting**.

---

## 🔐 In Vault’s Context

When you run:

```bash
vault operator init -key-shares=5 -key-threshold=3
```

Vault uses **Shamir’s Secret Sharing** to split the master key into 5 shares.
Any 3 of those can unseal Vault and reconstruct the real master key.
That way, **no single admin holds the full key alone**.

---

## ✅ Summary

* **Shamir** = key‑splitting algorithm (secret sharing).
* **Hashing** = one‑way fingerprinting (SHA‑256).
* **Encryption** = reversible scrambling with a key (AES).

---

✨ **Why Adi Shamir invented it:**
He recognized the danger of concentrating power in one person’s hands. By inventing SSS, he gave organizations a mathematical way to enforce distributed trust, collaboration, and resilience in critical security systems.
