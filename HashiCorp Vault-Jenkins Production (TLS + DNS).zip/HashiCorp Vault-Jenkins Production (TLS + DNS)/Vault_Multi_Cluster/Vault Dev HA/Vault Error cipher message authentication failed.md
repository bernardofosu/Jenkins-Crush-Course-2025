# ❌ Vault Error: `cipher: message authentication failed`

That error means the **unseal keys don’t match the data in the storage backend** (or the storage got changed/corrupted). Vault is saying: *“these shares can’t decrypt the master key I sealed with.”*

---

### 🔎 Most Common Causes

* 🔑 Using unseal keys from a **different init** (another node/old run).
* 🔄 Changed storage (e.g., `raft` ↔ `file`) or path but reused an old data dir.
* 📦 Moved/copied `/opt/vault/data` between machines.
* 🔐 Changed seal method (e.g., added/removed `seal "awskms"`) after data existed.
* 💾 Data/permissions corruption (rare): bad disk or wrong ownership.

---

### 🛠️ Quick Checks (no data loss)

Confirm storage matches how it was initialized:

```bash
# Look at config
sudo cat /etc/vault.d/vault.hcl

# Inspect data dir
sudo ls -l /opt/vault/data
sudo chown -R vault:vault /opt/vault
```

✅ Make sure you’re using the **exact shares** from this Vault init.

Unseal from CLI (avoid UI copy/paste issues):

```bash
export VAULT_ADDR="http://<EC2_PUBLIC_IP>:8200"
vault operator unseal
vault operator unseal
vault operator unseal
```

(Use 3 different shares, no extra spaces.)

Verify seal type:

* If you used `seal "awskms"` → keep it configured.
* If you used Shamir (default, no `seal` block) → keep it that way.

---

### 🔄 If You Want to **Recover Existing Data**

* Find the **correct unseal shares** for this `/opt/vault/data`.
* Restore the original `vault.hcl` (same seal + storage config).
* Restart and unseal:

```bash
sudo systemctl restart vault
vault operator unseal
```

---

### 🗑️ If You’re OK to **Start Fresh (Wipe)**

⚠️ This deletes all secrets in the Vault data dir.

```bash
sudo systemctl stop vault
sudo mv /opt/vault/data /opt/vault/data.bak.$(date +%s)
sudo mkdir -p /opt/vault/data
sudo chown -R vault:vault /opt/vault

sudo systemctl start vault

export VAULT_ADDR="http://<EC2_PUBLIC_IP>:8200"
vault operator init -key-shares=5 -key-threshold=3 > ~/vault_init.txt
# Unseal with 3 new shares
vault operator unseal
vault operator unseal
vault operator unseal
```

---

### 💡 Pro Tips to Avoid This

* 🚫 Never mix data dirs between nodes.
* 🛠️ For Raft HA, always start with **empty data dirs**, then join with `raft join`.
* 🔑 For painless restarts, set up **auto-unseal (AWS KMS/HSM)** before storing real data.
* 📝 If you get errors, check logs:

```bash
journalctl -xeu vault.service -n 100
```

⚠️ Sometimes **old keys** cause problems after a restart if the backend or seal method changed.
