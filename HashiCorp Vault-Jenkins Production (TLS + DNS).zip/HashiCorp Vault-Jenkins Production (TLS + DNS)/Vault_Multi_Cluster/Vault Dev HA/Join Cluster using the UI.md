# 🏗️ Creating Cluster using the UI

> [!NOTE]  
> You must first set the backend to **Raft** instead of **File**.  
> 
> - **File backend** → stores data locally on disk, works only for single-node dev/test.  
> - **Raft backend** → built-in consensus storage, replicates data across nodes, supports **HA (High Availability)** and fault tolerance.  
> 
> ✅ Use **Raft** for multi-node clusters.  

---

# 🟢 1. Without TLS (Dev/Lab Setup)

🔗 **Join an existing Raft cluster (Follower only)**  

🌍 **Leader API Address** →  
```
http://172.31.17.74:8200
```  

👉 Use **private IP** inside the same VPC/cluster.  

🔑 **Leader CA Certificate** → ❌ Leave empty  
📜 **Leader Client Certificate** → ❌ Leave empty  
🔐 **Leader Client Key** → ❌ Leave empty  

✅ After joining → unseal follower with the **same unseal keys** from the leader.  

---

⚡ **Important**  
- Followers do **not** run `vault operator init`.  
- Only the **leader** is initialized (gets unseal keys + root token).  
- All nodes in the cluster share the **same master keys/tokens** and replicate secrets.  

---

🌍 **Create a new Raft cluster (Leader only, once)**  

- Choose **Key shares** (e.g., 5)  
- Choose **Key threshold** (e.g., 3)  
- Vault generates **unseal keys + root token**  
✅ Store them safely!  

---

⚠️ **Pitfall**  
❌ If you click *Create a new cluster* on both nodes → you’ll form **two clusters** → follower join fails (`raft backend not in use`).  

---

✅ **Rule of Thumb (Dev)**  
- Leader 🟢 → Create new cluster  
- Followers 🔗 → Join existing cluster  
- TLS disabled → only API address needed 🌍  

---

# 🧪 Persistence Test (Secrets Replication)  

1️⃣ **On Leader**:  
```bash
vault kv put secret/app user=alice pass=12345
```  

2️⃣ **On Follower**:  
```bash
vault kv get secret/app
```  

✅ You should see:  
```
user  alice
pass  12345
```  

👉 Confirms secrets **persist and replicate** across all nodes.  

---

# ✅ Quick Memory  

- Only **leader** runs init → followers use leader’s unseal keys + root token.  
- Cluster = **shared state** → all nodes see the same secrets.  
- Test replication with `vault kv put` (leader) + `vault kv get` (follower).  
- 🔁 Do the same process when you want to **join more followers** to the cluster.  
