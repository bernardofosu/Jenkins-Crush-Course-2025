# 👥 Checking All Users on Linux

---

📜 **1. From `/etc/passwd`**
Every user account (normal + system) is listed in `/etc/passwd`.

```bash
cat /etc/passwd
```

Each line looks like:

```
username:x:UID:GID:comment:home_directory:login_shell
```

Example:

```
root:x:0:0:root:/root:/bin/bash
ubuntu:x:1000:1000:Ubuntu:/home/ubuntu:/bin/bash
vault:x:999:999::/etc/vault.d:/bin/false
```

---

📋 **2. Just usernames (cleaner view)**

```bash
cut -d: -f1 /etc/passwd
```

---

👥 **3. System vs. normal users**
On Ubuntu/Debian:

* System users → UID < 1000
* Normal users → UID ≥ 1000

Check:

```bash
awk -F: '$3 >= 1000 {print $1}' /etc/passwd
```

This will list only “real” login users.

---

🔍 **4. Check who is currently logged in**

```bash
who
w
```

---

🧾 **5. See groups too**

```bash
getent passwd
getent group
```

---

✅ **Confirm the `vault` account exists:**

```bash
id vault
grep vault /etc/passwd
```
