# 🌍 `api_addr` vs 🔗 `cluster_addr` in Vault

---

### 🌍 `api_addr`

* 👉 The **address Vault clients use** to connect (CLI, apps, curl).
* 🌐 Must be **reachable by clients** (public IP, DNS, or load balancer).
* 📌 Example:

  ```hcl
  api_addr = "http://EC2_PUBLIC_IP:8200"
  ```

---

### 🔗 `cluster_addr`

* 👉 The **address Vault nodes use to talk to each other** (Raft replication, HA leader election).
* 🛠️ Must be **reachable by peer nodes** (private IP, internal network).
* 📌 Example:

  ```hcl
  cluster_addr = "http://EC2_PRIVATE_IP:8201"
  ```

---

### 🖥️ `address = "0.0.0.0:8200"`

* 🎯 This is the **listener address for client traffic**.
* 🌐 `0.0.0.0` means “listen on all network interfaces” → accepts requests from anywhere that can reach the server.
* 🔌 Port **8200** = Vault API (CLI, curl, apps, UI).
* 📡 Works together with **`api_addr`**, which is what Vault tells clients to use when talking back.

---

### 🔗 `cluster_address = "0.0.0.0:8201"`

* 🎯 This is the **listener address for Vault node‑to‑node communication**.
* 🌐 `0.0.0.0` again means “bind all interfaces,” but in practice, other Vault nodes should connect via the **private IP** or DNS.
* 🔌 Port **8201** = cluster comms (Raft replication, leader election).
* 📡 Works together with **`cluster_addr`**, which is the advertised address other nodes use.

---

### ✅ Key difference

* 🖥️ **`address` (8200)** → for **clients** 🌍
* 🔗 **`cluster_address` (8201)** → for **peer nodes** 🔗

👉 Best practice in production: don’t leave both as `0.0.0.0`; instead, bind to the actual interface IP (e.g., private IP for `cluster_address`).

---

### ✅ Quick Memory Trick

* 🌍 **`api_addr` → for clients** (outside world / apps).
* 🔗 **`cluster_addr` → for peers** (inside Vault cluster).

---

✨ In dev/single-node → only `api_addr` is needed.
🚀 In HA/raft clusters → **both `api_addr` and `cluster_addr` are required**.
