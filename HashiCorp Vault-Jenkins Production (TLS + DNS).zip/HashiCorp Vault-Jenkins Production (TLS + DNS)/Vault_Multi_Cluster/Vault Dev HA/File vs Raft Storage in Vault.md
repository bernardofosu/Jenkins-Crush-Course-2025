# 📦 File vs Raft Storage in Vault

---

### ❌ Using `file` storage

```hcl
storage "file" {
  path = "/opt/vault/data"
  node_id = "vault-leader"   # (ignored for file)
}
```

* ⚠️ With **`storage "file"`**, there is **no cluster to join**.
* Any `raft join` from another node will fail with **“raft backend not in use.”**
* The `node_id` line is only meaningful for **Raft** and is ignored here.

---

### ✅ Fix: Switch to Raft (clean, learning setup)

#### 🟢 Leader `/etc/vault.d/vault.hcl`

```hcl
ui = true
disable_mlock = true

storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-leader"
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_disable     = 1
}

api_addr     = "http://50.17.109.80:8200"
cluster_addr = "http://172.31.17.74:8201"
```

**Apply on leader (fresh start):**

```bash
sudo systemctl stop vault
sudo rm -rf /opt/vault/data/*   # ⚠️ wipes existing secrets on this node
sudo systemctl start vault

export VAULT_ADDR="http://50.17.109.80:8200"
vault operator init -key-shares=5 -key-threshold=3 > ~/vault_init.txt
vault operator unseal
vault operator unseal
vault operator unseal
```

---

#### 🟢 Follower `/etc/vault.d/vault.hcl`

```hcl
ui = true
disable_mlock = true

storage "raft" {
  path    = "/opt/vault/data"
  node_id = "vault-node-2"

  retry_join {
    leader_api_addr = "http://50.17.109.80:8200"
  }
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_disable     = 1
}

api_addr     = "http://54.90.150.15:8200"
cluster_addr = "http://172.31.30.121:8201"
```

**Apply on follower (empty dir, don’t init here):**

```bash
sudo systemctl stop vault
sudo rm -rf /opt/vault/data/*   # ⚠️ wipes local data; will replicate from leader
sudo systemctl start vault

export VAULT_ADDR="http://54.90.150.15:8200"
# If retry_join not used, run:
# vault operator raft join http://50.17.109.80:8200

# Unseal follower with the SAME shares as the leader:
vault operator unseal
vault operator unseal
vault operator unseal
```

---

#### 🔍 Verify from leader

```bash
export VAULT_ADDR="http://50.17.109.80:8200"
vault operator raft list-peers
```

✅ You should see both peers (leader + follower).

---

⚠️ If you must **keep existing data** from `file`, don’t wipe — instead use Vault’s **migration flow** (`vault operator migrate`) to move from `file` → `raft`.
👉 For a clean **lab/demo cluster**, switching both nodes to **`storage "raft"`** is the simplest path.
