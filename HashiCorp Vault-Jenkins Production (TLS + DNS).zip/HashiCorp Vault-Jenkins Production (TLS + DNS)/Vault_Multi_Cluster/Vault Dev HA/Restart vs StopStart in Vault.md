# 🔄 Restart vs Stop/Start in Vault

---

### 🔄 `restart`

```bash
sudo systemctl restart vault
```

* ⏯️ Stops the process, then starts it again in one command.
* 🛠️ Used when you change the config (`vault.hcl`) or systemd unit.
* 🔐 Vault process restarts fresh → Vault is **sealed again** (you’ll need to unseal).

---

### ⏹️ + ▶️ `stop` + `start`

```bash
sudo systemctl stop vault
sudo systemctl start vault
```

* 🔄 Functionally the same as `restart`.
* ✂️ Just split into two steps.
* 🔐 Also results in Vault sealing again.

---

### 🔁 `reload` (ExecReload / SIGHUP)

```bash
sudo systemctl reload vault
```

* 📡 Sends a reload signal (if supported).
* ⚙️ In Vault’s systemd unit: `ExecReload=/bin/kill --signal HUP $MAINPID`.
* 🔐 With Vault, **reload does NOT unseal**; it only reloads some runtime settings (telemetry, audit sinks, some policies).
* ⚠️ Most core config (listener, storage, API/cluster addr) still requires a restart.

---

### 🔐 Sealing Behavior

* ⛔ Anytime the Vault process **stops** (stop/restart/crash), it comes up **sealed again**.
* 🔑 You must unseal it with your Shamir keys or via auto‑unseal (KMS/HSM).
* 🔁 A `reload` does **not** seal Vault, but applies only a few config changes.

---

### ✅ Summary

* 🔄 `restart` = `stop` + `start` → sealed again.
* ⏹️▶️ `stop/start` separately = same effect as `restart`.
* 🔁 `reload` = SIGHUP → Vault keeps running, not sealed, but only limited configs reload.
