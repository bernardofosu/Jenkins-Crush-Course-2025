# 🔐 Vault HA with Raft — Explained

## 🟢 Leader Node
- Mode: **active**
- Accepts **writes + reads**
- Stores data in Raft log
- Replicates to all followers

## 🔵 Follower Nodes
- Mode: **standby**
- Appear to accept writes… but 👉 they forward writes to the leader.
- Can serve **reads directly** (if redirect disabled) or proxy to leader (if enabled).
- Always replicate data from the leader’s Raft log.

## 🔑 Shared Secrets
- **Unseal keys + root token** come only from leader init.
- Followers are unsealed with the **same keys**.
- No separate tokens or keys for each node.

## 🔄 Replication
- Every write goes → **Leader → Raft log → Followers**
- Ensures all nodes have the same data.
- Like **Splunk RF (Replication Factor)** or **etcd consensus**.

## ⚡ Failover
- If leader dies → a follower is promoted to leader.
- Because Raft already replicated logs, the new leader has the same secrets.

## 📊 Analogy (Splunk vs Vault)
- Vault Leader = Splunk Indexer Captain
- Vault Followers = Splunk Peer Indexers
- Raft Replication = Splunk RF (Replication Factor)
- Write from any node = proxied to leader (like primary bucket in Splunk)

## 🧪 Quick Proof
```bash
vault status | grep 'HA Mode'
# Leader → active
# Follower → standby

vault status | grep 'Redirect'
# Follower shows leader redirect address
```
