# 🔑 Difference Between **SSM Parameter Store** vs **AWS Secrets Manager**

AWS **SSM Parameter Store** 🗂️ and **AWS Secrets Manager** 🔐 both store sensitive values (passwords, tokens, Vault unseal keys), but they differ in **features, cost, and best fit**.


## 📊 Quick Comparison

| Feature ⚖️ | SSM Parameter Store 🗂️ | AWS Secrets Manager 🔐 |
|---|---|---|
| **Primary CLI** | `aws ssm put-parameter` / `get-parameter` | `aws secretsmanager create-secret` / `get-secret-value` |
| **Cost 💰** | **Standard**: free (up to ~10,000 params). **Advanced**: ~$0.05/param/month. | ~$0.40/secret/month **+** per‑API call charges. |
| **Auto‑rotation 🔁** | ❌ No built‑in rotation (DIY via Lambda/cron). | ✅ Built‑in rotation (Lambda), native helpers for RDS & others. |
| **Versioning 📜** | ✅ Each update creates a new version; can fetch older versions. | ✅ Versioned; can stage versions (e.g., `AWSCURRENT`). |
| **Encryption 🔒** | `SecureString` uses KMS; `String` is plaintext. | Always KMS‑encrypted. |
| **Access control 👥** | IAM actions: `ssm:GetParameter`, `ssm:PutParameter`, etc. | IAM actions: `secretsmanager:GetSecretValue`, `secretsmanager:CreateSecret`, etc. |
| **Payload size ⬆️** | Up to **4 KB** (Standard) / **8 KB** (Advanced). | Up to **64 KB** per secret (JSON supported). |
| **Hierarchy / paths 🗂️** | ✅ Native hierarchical names: `/app/env/key`. | ➖ Flat names; you can simulate hierarchy in names. |
| **Typical use 🎯** | App configs, flags, cheaper storage for secrets. | High‑value secrets that need **rotation** & richer management. |
| **Console UX 🖥️** | Basic editor/viewer in **Systems Manager → Parameter Store**. | Rich UI (view JSON, configure rotation, replicas). |

> ℹ️ Limits and prices vary by region/account. Always check your current AWS pricing page for exact numbers.

---

## ✅ When to choose what?

- **Choose SSM Parameter Store 🗂️** when you want:
  - Lowest cost for many small values (configs, feature flags, Vault unseal keys if you rotate manually).  
  - Simple IAM + KMS usage and hierarchical paths.
- **Choose Secrets Manager 🔐** when you need:
  - **Automatic rotation**, built‑in patterns (DB creds), and staging labels.  
  - Larger payloads (JSON up to 64 KB), replication, rich auditing.

---

## 🔧 Common CLI Snippets

### SSM — create & read
```bash
# Create/update (SecureString with KMS)
aws ssm put-parameter   --name "/vault/unseal-keys"   --type "SecureString"   --value file://vault-unseal.json   --overwrite

# Read (pretty print)
aws ssm get-parameter   --name "/vault/unseal-keys"   --with-decryption   --query 'Parameter.Value' --output text | jq .
```

### Secrets Manager — create & read
```bash
# Create (JSON file)
aws secretsmanager create-secret   --name "vault/unseal-keys"   --secret-string file://vault-unseal.json

# Read (pretty print)
aws secretsmanager get-secret-value   --secret-id "vault/unseal-keys"   --query 'SecretString' --output text | jq .
```

> 🔐 **KMS**: Reading encrypted values requires `kms:Decrypt` on the CMK used.

---

## ⚡ TL;DR

- **Parameter Store** 🗂️ = **cheaper, simpler**, great for configs and secrets **you rotate yourself**.  
- **Secrets Manager** 🔐 = **costs more**, but gives **automatic rotation**, staging labels, and a richer management experience.

